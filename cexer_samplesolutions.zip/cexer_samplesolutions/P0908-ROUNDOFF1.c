/*
P0908 : ROUNDOFF1.C � Roundoff Function
[Learning Goal : Writing User Defined Functions]
Write a function to roundoff a given real value to the specified number of digits after the decimal
point. The number of digits is the precision to which roundoff is desired. Use the prototype
double roundoff(double value, int precision)
If the value is 3493.363, the following results are expected after roundoff.
For precision = 0, output will be 3493.000
For precision = 1, output will be 3493.400
For precision = 2, output will be 3493.360
For precision = -1, output will be 3490.000
For precision = -2, output will be 3500.000
*/

#include<stdio.h>
#include<stdlib.h>
#include<math.h>
double roundoff(double value, int precision);

int main()

{
	double myNum=0.0;
	int precision=0;
	
	printf("Enter the Number >> ");
	scanf("%lf",&myNum);
	
	printf("Enter the Precision value >> ");
	scanf("%d",&precision);
	
	printf("The value %.3lf is %.3lf\n",myNum,roundoff(myNum,precision));
	
	


    system("PAUSE");
    return 0;
}
double roundoff(double value, int precision)
{
	
	return round(pow(10,precision)*value)/pow(10,precision);
	
}
