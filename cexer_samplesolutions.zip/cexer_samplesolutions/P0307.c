/*
P0307 : ROUND2.C � Roundoff to Nearest 100
[Learning Goal : integer arithmetic, roundoff]
Read in a positive integer entered by user.
Print out the value rounded to nearest 100 using standard rules of rounding off.
Code fragment:
int k;
user enters value of k here
k = k/100.0+0.5;
k = k*100;
print out value of k rounded to nearest 100
SAMPLE SESSION #01
Enter an integer : 6475
6475 rounded to nearest 100 is 6500
Hint:
6475/100.0 gives us decimal value 64.75. (Note that we must divide by 100.0 and not 100
because 100 is an integer and 6475/100 will give us 64)
Adding 0.5 (65.25) and truncating gives us 65.
65 multiplied by 100 is 6500 which is 6475 rounded off to nearest 100.
*/

#include<stdio.h>
#include<stdlib.h>


int main()

{

  int k=0;
  float p=0.0,q=0.0;
  
  
  printf("Enter positive  value for k >>");
  scanf("%d",&k);
  printf("You have entered : %d\n",k);
  
  k = k/100.0+0.5;
  k = k*100;

  
  printf("The round of value  is %d\n",k);
  
     
  system("PAUSE");
  return 0;
}

