/*
P1112 : PALIND.C � Palindromic Sentences
[Learning Goal : Working with Strings]
Write a program which takes one sentence as input and checks whether or not it is a
palindrome. For this, we must ignore spaces and the case of the text.

*/

#include<stdio.h>
#include<stdlib.h>
#include <ctype.h>
int is_palindrome(char str[]);

int main()

{
	char myChar[100],copyText[100];
	int i=0,j=0,flag=0;

	printf("Enter a line of text >> ");
	gets(myChar);

	while(myChar[i]!='\0')
	{

		if (myChar[i] == ' ' )
		  {
		     //copyText[j]='';
		     //j++;
			 while(myChar[i] == ' ' )
		      {
			   i++;
		      }

          }
        else
          {
        	copyText[j]=tolower(myChar[i]);
        	i++; j++;
		  }


	}
	copyText[j]='\0';

   printf("The Modified String without space is [%s] \n",copyText);

   flag=is_palindrome(copyText);

    if(flag==1)
      printf("The string is palindrome\n");
    else
	  printf("The string is not palindrome\n");


    system("PAUSE");
    return 0;
}



int is_palindrome(char str[])
{

char tmp;
int i=0,len=0,half=0,flag=1;

for(i=0;str[i]!='\0';i++)
   len++;

half=len/2;

for(i=0;i<half;i++)
   {
   if(str[len-i-1]!=str[i])
     {
     flag=0;
     break;
     }
   }
return flag;
}

