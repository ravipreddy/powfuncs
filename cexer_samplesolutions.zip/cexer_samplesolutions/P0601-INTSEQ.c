/*
P0601 : INTSEQ.C � Integer Sequence
[Learning Goal : Simple looping]
Write a program to print all integers from 1 to 100.
*/

#include<stdio.h>
#include<stdlib.h>

int main()

{
    int myNum=1,i=0;
    for(i=0;i<100;i++)
    {
		printf("%d  ",myNum);
        myNum++;
    }


    system("PAUSE");
    return 0;
}

