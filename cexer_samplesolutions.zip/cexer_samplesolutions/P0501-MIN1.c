/*
P0501 : MIN1.C � Print smaller integer
[Learning Goal : Simple comparisons]
Write a program to accept two integers entered by the user and print out the smaller of the
two numbers.
*/
#include<stdio.h>
#include<stdlib.h>

int main()

{

    int myNum1=0,myNum2=0;
    
    printf("Enter first integer number >> ");
    scanf("%d",&myNum1);
    
    printf("Enter second integer number >> ");
    scanf("%d",&myNum2);

    if(myNum1>myNum2)
        printf("Out of %d and %d the smaller number is %d\n",myNum1,myNum2,myNum2);
    else
        printf("Out of %d and %d the smaller number is %d\n",myNum1,myNum2,myNum1);

  system("PAUSE");
  return 0;
}

