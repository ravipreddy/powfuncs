/*
P0312 : CELSIUS.C � Temperature Conversion
[Learning Goal : arithmetic, io]
Given a value of temperature in degrees Fahrenheit, write a program to convert it into
degrees Celsius. [use the formula C = (F-32)/1.8]
*/

#include<stdio.h>
#include<stdlib.h>
#define PIVALUE 3.141592

int main()

{

  float degreeF=0.0f,degreeC=0.0f;
  //0.0 if is double constant suffice f convent 0.0 to float
  
  
  printf("Enter  value of Temperature in degree Fahrenheit >>");
  scanf("%f",&degreeF);
  printf("You have entered : %g\n",degreeF);
  
  degreeC=(degreeF-32)/1.8;
  
  printf("The degree Celsius of Temperature %gF is %gC\n",degreeF,degreeC);
  
      
  system("PAUSE");
  return 0;
}

