/*
P0702 : DIGPAT1.C � Digit Pattern 1
[Learning Goal : Nested Looping]
Write a program which, given an integer n as input, generates a pyramid of n lines using the
last digit of the line number (starting from 1). The output for n=7 is shown below as an
example.
Input size n >> 7
1
222
33333
4444444
555555555
66666666666
7777777777777
*/

#include<stdio.h>
#include<stdlib.h>

int main()

{
	int myNum=0,i=0,j=0;
	
	printf("Enter an integer value >> ");
	scanf("%d",&myNum);
	
	for(i=0;i<myNum;i++)
	{
		for(j=0;j<=i;j++)
		 {
		   printf("%2d",i+1);
	     }
	    
		printf("\n"); 
	}


    system("PAUSE");
    return 0;
}

