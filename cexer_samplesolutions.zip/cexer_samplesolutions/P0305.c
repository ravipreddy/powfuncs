/*
P0305 : MIXED.C � Mixed Arithmetic
[Learning Goal : mixed arithmetic]
Read in a decimal value p and an integer value k entered by user and print out the following
values,
p+k p-k p*k p/k
Code fragment:
int k;
float p,q;
user enters value of k here
user enters value of p here
q = p+k;
print out sum of p and k here
... other expressions
Hint: When an arithmetic operation is performed involving one decimal value and one integer
value, the result should be stored in a decimal format.

*/

#include<stdio.h>
#include<stdlib.h>


int main()

{

  int k=0;
  float p=0.0,q=0.0;
  
  
  printf("Enter decimal value for p >>");
  scanf("%f",&p);
  printf("You have entered : %g\n",p);
  
   
  
  printf("Enter integer value for k >>");
  scanf("%d",&k);
  printf("You have entered :%d\n",k);
  
  q=p+k;
  printf("Result of p+k is %f\n",q);
  
  q=p-k;  
  printf("Result of p-k is %f\n",q);
  
  q=p*k;
  printf("Result of p*k is %f\n",q);
  
  q=p/k;
  printf("Result of p/k is %f\n",q);

  
     
  system("PAUSE");
  return 0;
}

