/*
P0711 : STARPAT.C � Printing a Pattern of Stars
[Learning Goal : Nested Looping]
Write a C program that will accept input of a positive integer value N and output a pattern of
stars based on N.
Input a number>> 6
*
* *
* * *
* * * *
* * * * *
* * * * * *

*/

#include<stdio.h>
#include<stdlib.h>

int main()

{
	int myNum=0,i=0,j=0,k=0;
	
	printf("Enter the positive Number >> ");
	scanf("%d",&myNum);
	
	for(i=0;i<myNum;i++)
	{
		for (j=0;j<i+1;j++)
		{
			printf("%c ",'*');
		}
		
		printf("\n");
		
	}



    system("PAUSE");
    return 0;
}

