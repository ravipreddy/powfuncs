/*
P0621 : DIV13.C � Printing Hexadecimal Equivalent
[Learning Goal : Simple logic, hexadecimal format output]
Write a program to print the 32 bit hexadecimal equivalent of a given positive integer.
*/

#include<stdio.h>
#include<stdlib.h>

int main()

{
	int myNum=0;
	
	printf("Enter an integer value >> ");
    scanf("%d",&myNum);
    
    printf("The Hexa Equivalent of %d is %X\n",myNum,myNum);



    system("PAUSE");
    return 0;
}

