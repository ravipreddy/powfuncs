/*
P1207 : BINOM.C � Recursive Computation of Binomial Coefficients
[Learning Goal : Writing Recursive Functions]
The binomial coefficients can be defined recursively as
C(n,r) = C(n-1,r) + C(n-1,r-1)
with the initial conditions that if n and r are positive integers, then
C(n,r) = 1, when n equals r, and
C(n,0) = 1
Write a program with a recursive function binom_coffs that will take n and r as inputs and
calculate the corresponding binomial coefficient.
int binom_coffs(int n, int r);
*/

#include<stdio.h>
#include<stdlib.h>
int binom_coffs(int n, int r);

int main()

{
	int n=0,r=0;

	printf("Enter value for n : ");
	scanf("%d",&n);

	printf("Enter value for r : ");
	scanf("%d",&r);

	if(n>=r)
        printf("\nBinomial coefficient %d\n",binom_coffs(n,r));
    else
        printf("n cannot be less than r\a\n");

    return 0;
}
int binom_coffs(int n, int r)
{
	if(r==0 || r==n)
	return 1;
	return binom_coffs(n-1,r-1) + binom_coffs(n-1,r);
}


