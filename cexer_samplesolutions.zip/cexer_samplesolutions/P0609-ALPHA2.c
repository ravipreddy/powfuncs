/*
P0609 : ALPHA2.C � Lower and Upper Case Alphabet Printing
[Learning Goal : Simple looping, using char as loop index]
Write a program to print the upper case and lowercase alphabets in the following pattern.
aAbBcCdDeE.....
*/

#include<stdio.h>
#include<stdlib.h>

int main()

{
    char myChar=NULL;
    
    for(myChar='a';myChar<='z';myChar++)
       printf("%c%c",myChar,myChar-32);

    system("PAUSE");
    return 0;
}

