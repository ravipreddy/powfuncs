/*
P1013 : RIGHTROT.C � Array Rotation
[Learning Goal : Using One Dimensional Arrays]
Write a function to right rotate the elements of an integer array by one place.
void rightt_rotate(int * arr, int arrsize);
The original array of [1,2,3,4,5,6] becomes [6,1,2,3,4,5]. Do not make a copy of the array. 
*/

#include<stdio.h>
#include<stdlib.h>

void right_rotate(int * arr, int arrsize);

int main()

{
	int count=0,i=0;
	int array[count];
	
	printf("Enter the value of Element in array >>");
	scanf("%d",&count);
	
	for(i=0;i<count;i++)
	{
		printf("Enter the %d element for integer array >> ",i+1);
		scanf("%d",&array[i]);
	}
    
    printf("Before Rotation the Array is\n");
    
    for(i=0;i<count;i++)
	{
		printf("%d\t",array[i]);
		
	}
    right_rotate(array, count);
    
    
    printf("\nAfter Rotation the Array is\n");
    
    for(i=0;i<count;i++)
	{
		printf("%d\t",array[i]);
		
	}

    printf("\n");
	system("PAUSE");
    return 0;
}
void right_rotate(int * arr, int arrsize)
{
	int i=0,temp;
	temp=arr[arrsize-1];
	for(i=arrsize-1;i>0;i--)
	{
	  arr[i]=arr[i-1];	
	}
	arr[i]=temp;
	
	}

