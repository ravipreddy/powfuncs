/*
P0610 : ALPHA3.C � Alphabet Printing
[Learning Goal : Simple looping]
Write a program to print the upper case and lowercase alphabets in the following pattern.
1 a A
2 b B
3 c C
.... and so on
*/

#include<stdio.h>
#include<stdlib.h>

int main()

{
    int myNum=1,i=1;
	char myChar='a';
    
    for(i=0;i<26;i++)
    {
	   printf("%2d  %c  %c\n",myNum,myChar,myChar-32);
	   myNum++;
	   myChar++;
    }

    system("PAUSE");
    return 0;
}

