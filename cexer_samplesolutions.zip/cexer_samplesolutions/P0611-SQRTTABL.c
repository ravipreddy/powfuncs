/*
P0611 : SQRTTABL.C � Square Root Table Printing
[Learning Goal : Simple looping]
Write a program to print the squares and the square roots of the first 50 integers from 1 to
50.
1 1 1
2 4 1.4142
3 9 1.7321
.... and so on
*/

#include<stdio.h>
#include<stdlib.h>
#include<math.h>

int main()

{
    int myNum=1,i=0, square=0; 
	double squareRoot=0;
    
    for(i=0;i<50;i++)
    {
      square=pow(myNum,2);
	  squareRoot=sqrt(myNum);	
      printf("%2d  %4d   %g\n",myNum,square,squareRoot);
	  myNum++;	
	}

    system("PAUSE");
    return 0;
}

