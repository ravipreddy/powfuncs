/*
P0906 : RECT.C � Rectangle Functions
[Learning Goal : Writing User Defined Functions]
Write a program which contains user defined functions rect_area and rect_peri with the
following function prototypes.
double rect_area (double width, double length);
double rect_perimeter (double width, double length);
where width and length are the two dimensions of the rectangle.
*/

#include<stdio.h>
#include<stdlib.h>

double rect_area (double width, double length);
double rect_perimeter (double width, double length);

int main()

{
	double width=0.0,length=0.0;
	
	printf("Enter the width of rectangle >>");
	scanf("%lg",&width);
	
	printf("Enter the length of rectangle >> ");
	scanf("%lg",&length);
	
	printf("The area of rectangle of side %g and %g is %g\n",width,length,rect_area(width,length));
	printf("The perimeter of rectangle of side %g and %g is %g\n",width,length,rect_perimeter(width,length));


    system("PAUSE");
    return 0;
}
double rect_area (double width, double length)
{
	return width*length;
}

double rect_perimeter (double width, double length)
{
	return 2*width*length;
}
	

