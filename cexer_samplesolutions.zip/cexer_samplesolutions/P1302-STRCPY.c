/*
P1302 : STRCPY.C � String Copy Function
[Learning Goal : Using Pointers]
Write a program using a user defined function for performing string copying.
void my_strcpy (char *t, char *s)
*/

#include<stdio.h>
#include<stdlib.h>

void my_strcpy (char *t, char *s);
int main()

{
	char myChar[100],copystr[100];
	
	printf("Enter the String >> ");
	gets(myChar);
	
	my_strcpy(copystr,myChar);
	
	printf("The string is %s\n",copystr);


    system("PAUSE");
    return 0;
}

void my_strcpy (char *t, char *s)
{
	int i=0;
	while(s[i]!='\0')
	{
		t[i]=s[i];
		i++;
	}
	t[i]='\0';
	return ;
}
