/*
P0619 : BINBITS.C � Writing Binary Equivalent
[Learning Goal : Simple logic, looping]
Write a program to print the 32 bit binary equivalent of a given positive integer.

*/

#include<stdio.h>
#include<stdlib.h>

int main()

{
	int myNum=0,c=0,temp=0;
	
	printf("Enter an integer value >> ");
    scanf("%d",&myNum);
    
        
    for(c=31;c>=0;c--)
    {
    temp=myNum>>c;// myNum>>c is equal to myNum divided by 2^c

    if (temp)
      printf("1");
    else
      printf("0");

      if(c%4==0) 
	    printf(" ");
    }
    
    system("PAUSE");
    return 0;
}

