/*
P0505 : DIV13.C � Checking for divisibility
[Learning Goal : Integer divisibility]
Write a program to accept an integer and check whether it is divisible by 13 or not.
*/
#include<stdio.h>
#include<stdlib.h>

int main()

{
  int myNum=0;
  
  printf("Enter the integer number >> ");
  scanf("%d",&myNum);
    
  if(myNum%13==0)
   printf("The Number %d is divisible by 13\n",myNum);
  else
   printf("The Number %d is NOT divisible by 13\n",myNum);  


  system("PAUSE");
  return 0;
}

