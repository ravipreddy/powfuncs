/*
P1206 : HANOI.C � Towers of Hanoi
[Learning Goal : Writing Recursive Functions]
The Towers of Hanoi (sometimes known as the Towers of Banaras) is another classic problem
for which recursion provides an elegant solution. There are 64 golden disks placed on one of
three diamond pins. Each disk is slightly smaller than the disk placed under it. The task is to
move all disks from Pin 1 to Pin3 subject to the following rules: (a) Only one disk can be moved
from one pin to another pin, (b) a disk must never be placed over a disk of smaller size.
*/

#include<stdio.h>
#include<stdlib.h>
void hanoi(int numdisks, int pin1, int pin3, int pin2);

int main()

{
	int numDisk=0;
    printf("Enter the Number Of Disk : ");
    scanf("%d",&numDisk);

    hanoi(numDisk, 'A', 'C', 'B');



    system("PAUSE");
    return 0;
}
void hanoi(int numdisks, int pin1, int pin3, int pin2)
{
    if (numdisks == 1)
    {
        printf("Move disk 1 from Pin %c to Pin %c\n", pin1, pin3);
        return;
    }
    hanoi(numdisks-1, pin1, pin2, pin3);
    printf("Move disk %d from Pin %c to Pin %c\n", numdisks, pin1, pin3);
    hanoi(numdisks-1, pin2, pin3, pin1);
}


