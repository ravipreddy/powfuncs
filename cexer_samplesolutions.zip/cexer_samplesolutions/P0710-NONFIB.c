/*
P0710 : NONFIB.C � Non Fibonacci Numbers
[Learning Goal : Nested Looping]
Write a C program that will accept input of a positive integer value N and output the numbers
that do NOT occur in the Fibonacci sequence up to N, i.e., print all non-Fibonacci numbers
less than N.
(Hint: The outer loop goes through the Fibonacci sequence. The inner loop prints the nonFibonacci numbers)
Input a limit >> 20
The non-Fibonacci numbers less than 20 are
4 6 7 9 10 11 12 14 15 16 17 18 19

*/

#include<stdio.h>
#include<stdlib.h>

int main()

{
	int next=0,firstNum=1,secondNum=1,i=0,j=0;
	int myNum=0;
	
	printf("Enter a positive number >> ");
	scanf("%d",&myNum);
    
    for(i=0;i<myNum;i++)
    {
        
        next=firstNum+secondNum;        
		secondNum=firstNum;
		firstNum=next;
		
		for(j=secondNum+1;j<firstNum;j++)
		  if(j<myNum)
		   printf("%d ",j);
			
	}
    printf("\n");

    system("PAUSE");
    return 0;
}

