/*
P1104 : VSTRIP.C � Strip Vowels
[Learning Goal : Working with Strings]
Write a program which takes in a line of text entered by the user and removes all vowels from
the text.

*/

#include<stdio.h>
#include<stdlib.h>

int isVowel(char ch);

int main()

{
	char myChar[100],copyText[100];
	int i=0,j=0;
	
	printf("Enter a line of text >> ");
	gets(myChar);
	
	for(i=0;myChar[i]!='\0';i++)
	{
		if(isVowel(myChar[i]))
		  {
		  	continue;
		  }
		else
		  {
		  	copyText[j]=myChar[i];
		  	j++;
		  }
		  
		
		
		
	}
	
	copyText[j]=='\0';
   
   printf("The Modified String is [%s] \n",copyText);


    system("PAUSE");
    return 0;
}

int isVowel(char ch)
{
    if (ch == 'a' || ch == 'A' || ch == 'e' || ch == 'E' || ch == 'i' || ch == 'I' || ch =='o' || ch=='O' || ch == 'u' || ch == 'U')
      return 1;
    else
      return 0;
}


