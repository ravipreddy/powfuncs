/*
P1004 : FINDINT.C � Search for Integer Value
[Learning Goal : Using One Dimensional Arrays]
Write a program to read a set of positive integer values from a text file and store them in an
integer array. The program then takes an integer key value given by the user and searches
for it in the array using a function lin_search.
int lin_search(int n, int vals, int key);
If found, it prints the location of the first occurrence of this value. If not found, the function
returns -1.
*/

#include<stdio.h>
#include<stdlib.h>

int lin_search(int n, int vals[], int key);

int main()

{
	FILE *fptr;
    char fileName[100] ;
    int i=0,count=0,myNum[100],search=0,index=0;
    
    
    printf("Enter the file(vals.txt) to be opened >>");
    gets(fileName);
    
    
    fptr=fopen(fileName,"r");
    
    while(!feof(fptr))
        {
        fscanf(fptr,"%d",&myNum[i]);
        count++;
        i++;
        }
        
    printf("The total values are %d\n",count);
    printf("Input key value to search >> ");
    scanf("%d",&search);
    
    index=lin_search(count,myNum,search);
    
    if(index>=0)
	  printf("%d is at %d\n",search,index);
	else
	  printf("%d is not in the Array\n",search);  



    system("PAUSE");
    return 0;
}

int lin_search(int n, int vals[], int key)
{
	int j;
    for(j=0;j<n;j++)
    {
    	if(vals[j]==key)
            return j;
	}
        
    return -1;

	
}
