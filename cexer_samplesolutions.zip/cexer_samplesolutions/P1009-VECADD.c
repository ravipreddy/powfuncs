/*
P1009 : VECADD.C � Vector Addition
[Learning Goal : Using One Dimensional Arrays]
Write a program which performs vector addition where the elements of a vector are stored as
a double array. It should use a function with the following prototype:
void vec_add(int n, double x, double y, double sum);
where sum[i] = x[i] + y[i] for each i.
*/

#include<stdio.h>
#include<stdlib.h>

void vec_add(int n, double x[], double y[], double sum[]);

int main()

{
	int count=0;
	double x[100],y[100],z[100];
	int i=0;

	printf("Enter the size of vector Element >>");
	scanf("%d",&count);
	if(count >100)
        count=100;
	printf("Vector has %d elements\n",count);

	for(i=0;i<count;i++)
	{
		printf("Enter the %d element for vector 1 >> ",i+1);
		scanf("%lg",&x[i]);
	}

	for(i=0;i<count;i++)
	{
		printf("Enter the %d element for vector 2 >> ",i+1);
		scanf("%lg",&y[i]);
	}

	vec_add(count,x,y,z);

	for(i=0;i<count;i++)
	{
		printf("The %d element of added Vector is %lg\n",i+1,z[i]);

	}



    system("PAUSE");
    return 0;
}

void vec_add(int n, double x[], double y[], double sum[])
{
	int i=0;

	for(i=0;i<n;i++)
	{
	   sum[i]=x[i]+y[i];
	}

	return;
}

