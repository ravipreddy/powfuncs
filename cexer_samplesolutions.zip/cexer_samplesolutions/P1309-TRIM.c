/*
P1309 : TRIM.C � Whitespace Removal
[Learning Goal : Using Pointers]
Write a function to trim the ONly leading and trailing whitespace characters in a string. The function
prototype should be
void str_trim(char *str);

*/

#include<stdio.h>
#include<stdlib.h>

void str_trim(char *str);

int main()

{
	char myChar[100];
	
	printf("Enter the String >> ");
	gets(myChar);
	
	printf("The entered string is [%s]\n",myChar);
	
	str_trim(myChar);
	
	printf("The modified string is [%s]\n",myChar);


    system("PAUSE");
    return 0;
}

void str_trim(char *str)
{
	int i=0,index=0;
	
	while(str[index]==' ' || str[index]=='\t')
      index++;


    while(str[i+index]!='\0')
    {
        str[i]=str[i+index];
        i++;
    }
    str[i] = '\0';
    
    
	
	i = 0;
    index = -1;
    
    while(str[i]!='\0')
    {
        if(str[i]!=' ' && str[i]!='\t')
         index = i;

        i++;
    }

    str[index+1]='\0';
    
	return ;
	
}

