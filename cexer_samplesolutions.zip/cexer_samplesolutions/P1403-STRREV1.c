/*
P1403 : STRREV1.C � String Reverse Function
[Learning Goal : Using Dynamic Memory Allocation]
Write a program using a user defined function which returns the reverse of a string as a new
string, i.e., the original string remains unchanged. (NOTE: This is different from the usual strrev
function that reverses the string that is passed as argument and the original string is
destroyed.)
char * my_strrevnew (char *str);
*/

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

char * my_strrevnew (char *str);

int main()

{
	char str[100];
	
    printf("Enter the String >>  ");
    gets(str);

    char* cpystr = my_strrevnew(str);

    printf("String [%s] after reversing is [%s]\n", str,cpystr);



    system("PAUSE");
    return 0;
}

char * my_strrevnew (char *str)
{
	int len=strlen(str),i=0;
    char *reverse =(char*) malloc (len + 1);
    for(i = 0; i < len ; i++)
       reverse[i] = str[(len - 1) - i];

    if (reverse != NULL)
    return reverse;

	
}

