/*
P0310 : CIRCLE.C � Circle Geometry
[Learning Goal : arithmetic, io]
Given the radius of a circle entered by the user, compute and display the diameter,
circumference and area of the circle.
NOTE: Declare and use a symbolic constant PIVALUE for this
#define PIVALUE 3.141592

*/

#include<stdio.h>
#include<stdlib.h>
#define PIVALUE 3.141592

int main()

{

  float radius=0.0,area=0.0, dia=0.0, circum=0.0;
  
  
  printf("Enter  value for radius of Circle >>");
  scanf("%f",&radius);
  printf("You have entered : %g\n",radius);
  
  dia=2*radius;
  area=PIVALUE*radius*radius;
  circum=2*PIVALUE*radius;
  
  printf("The dia of the circle of radius %g is %g\n",radius,dia);
  printf("The area of the circle of radius %g is %g\n",radius,area);
  printf("The Cicumference of the circle of radius %g is %g\n",radius,circum);
  
      
  system("PAUSE");
  return 0;
}

