/*
P0704 : DIGPAT3.C � Digit Pattern 3
[Learning Goal : Nested Looping]
Write a program which, given an integer n as input, generates a pyramid of n lines. The
output for n=7 is shown below as an example. 
Input size n >> 7
       1
      212
     32123
    4321234
   543212345
 65432123456
7654321234567
*/

#include<stdio.h>
#include<stdlib.h>

int main()

{
	int myNum=0,i=0,j=0,k=0;
	
	printf("Enter the positive Number >> ");
	scanf("%d",&myNum);
	
	for(i=0;i<myNum;i++)
	{
		for (j=0;j<myNum-i-1;j++)
		{
			printf("%c",' ');
		}
		
		for(k=0;k<(i*2)+1;k++)
		  {
		  	if(k<i)
                printf("%d",i-k+1);
            else
                printf("%d",k-i+1);

		  }
		printf("\n");
	}


    system("PAUSE");
    return 0;
}

