/*
P0606 : FILTER.C � Filtering Integers
[Learning Goal : Simple looping]
Write a program which prints all the integers from 1 to 200 except those which are multiples
of 7 or 13.
*/

#include<stdio.h>
#include<stdlib.h>

int main()

{
	int myNum=0,i=0;

	for(i=0;i<200;i++)
    {
		myNum++;
		if(myNum%7!=0 && myNum%13!=0)
		printf("%3d ",myNum);

    }


    system("PAUSE");
    return 0;
}

