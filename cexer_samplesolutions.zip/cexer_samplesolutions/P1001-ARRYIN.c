/*
P1001 : ARRYIN.C � Reading an Array of Values
[Learning Goal : Using One Dimensional Arrays]
Write a program which allows the user to input a certain number of integer values and store
them in an integer array. The number of values to be entered will be given by the user subject
to a maximum limit of 100 integers. 
*/

#include<stdio.h>
#include<stdlib.h>

int main()

{
	int myNum[100],value=0,i=0;
	
	printf("Enter the value you want Enter >>");
	scanf("%d",&value);
	
	if(value>100)
	{
		printf("You can only enter 100 values\n");
		system("PAUSE");
		exit(0);
	}
	
	for(i=0;i<value;i++)
	{
		printf("Enter value %d >> ",i+1);
		scanf("%d",&myNum[i]);
	}
	
	for(i=0;i<value;i++)
	{
		printf("\nThe value entered is %d ",myNum[i]);
	}


    printf("\n");
    system("PAUSE");
    return 0;
}

