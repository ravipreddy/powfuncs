/*
P0406 : FABS.C � Absolute value computation
[Learning Goal : Using fabs function]
Write a program to read a decimal value and print its absolute value using fabs function.
*/
#include<stdio.h>
#include<stdlib.h>
#include<math.h>

int main()

{
	double myNum=0.0;
	double absValue=0.0;
    printf("Enter the decimal value >> ");
    scanf("%lf",&myNum);

    absValue=fabs(myNum);
    printf("Absolute Value of %g is  %g\n",myNum,absValue);


  system("PAUSE");
  return 0;
}

