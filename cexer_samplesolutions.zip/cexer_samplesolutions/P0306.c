/*
P0306 : ROUND1.C � Rounding Off
[Learning Goal : integer arithmetic, roundoff]
Read in a positive floating point value given by user.
Print out the value rounded to nearest integer using standard rules of rounding-off.
[HINT: Add 0.5 to the decimal value and truncate it using integer truncation.]
Code fragment:
int k;
float p;
user enters value of p here
k = p+0.5;
print out rounded off value k
Hint: Examples showing how roundoff is achieved:
Given p =2.6, p+0.5 equals 3.1, which after integer truncation becomes 3 (rounded value)
Given p =2.4, p+0.5 equals 2.9, which after integer truncation becomes 2 (rounded value)
*/

#include<stdio.h>
#include<stdlib.h>


int main()

{

  int k=0;
  float p=0.0,q=0.0;
  
  
  printf("Enter positive decimal value for p >>");
  scanf("%f",&p);
  printf("You have entered : %g\n",p);
  
  k=p+0.5;
  
  printf("The round of value of %g is %d\n",p,k);
  
   
  
  
     
  system("PAUSE");
  return 0;
}

