/*
P1106 : DOTSPACE.C � Replace Spaces
[Learning Goal : Working with Strings]
Write a program which takes in a line of text which contains one or more spaces between
words. In the output, replace each set of spaces with a single '.' character.

*/

#include<stdio.h>
#include<stdlib.h>

int main()

{
	char myChar[100],copyText[100];
	int i=0,j=0;
	
	printf("Enter a line of text >> ");
	gets(myChar);
	
	while(myChar[i]!='\0')
	{
		
		if (myChar[i] == ' ' )
		  {
		     copyText[j]='.';
		     j++;
			 while(myChar[i] == ' ' )
		      {
			   i++;
		      }		  
		  
          }
        else
          {
        	copyText[j]=(myChar[i]);
        	i++; j++;
		  }
		  	
		
	}
	copyText[j]='\0';
   
   printf("The Modified String is [%s] \n",copyText);


    system("PAUSE");
    return 0;
}

