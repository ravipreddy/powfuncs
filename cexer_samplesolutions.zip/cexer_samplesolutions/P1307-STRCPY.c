/*
P1307 : STRCPY.C � String Copy Function
[Learning Goal : Using Pointers]
Write a program that reads text from a file and prints the frequency count of words of different
length.
*/

#include<stdio.h>
#include<stdlib.h>

int main()

{
	FILE *fptr;
	int i=0,one=0,two=0, three=0,four=0,five=0,six=0,seven=0,length=0;
    char fileName[100], buf[100];

    printf("Enter the filename (Samp.txt) to open >> ");
    scanf("%s", fileName);
    

    fptr = fopen(fileName, "r");
    
    if (fptr == NULL)
    {
        printf("Cannot open file \n");
        exit(0);
    }
    
    printf("The content of the file are\n");
    
    while( fscanf(fptr, "%s", buf) != EOF )
        {
            printf("%s ", buf);
            while(buf[i]!='\0'&& buf[i]!='.')
             {
             	length++;
             	i++;
			 }
            if(length==1)
              one++;
            if(length==2)
              two++;
            if(length==3)
              three++;
            if(length==4)
              four++;
            if(length==5)
              five++;
            if(length==6)
              six++;
            if(length==7)
              seven++;
			
			length=0;
			i=0;    
        }
    
    
    printf("\n\nTotal word with 1 letter is %d\n",one);
    printf("Total word with 2 letter is %d\n",two);
    printf("Total word with 3 letter is %d\n",three);
    printf("Total word with 4 letter is %d\n",four);
    printf("Total word with 5 letter is %d\n",five);
    printf("Total word with 6 letter is %d\n",six);
    printf("Total word with 7 letter is %d\n",seven);

    fclose(fptr);
    
    printf("\n");

    system("PAUSE");
    return 0;
}

