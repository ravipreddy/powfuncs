/*
P0313 : RECIP1.C � Reciprocal Computation
[Learning Goal : arithmetic, io]
Given a decimal value, print its reciprocal value. For a number p, the reciprocal is defined as
the value 1/p.
*/

#include<stdio.h>
#include<stdlib.h>
#define PIVALUE 3.141592

int main()

{

  double val=0.0,reci=0.0;
    
  printf("Enter  decimal value  >>");
  scanf("%lf",&val);
  printf("You have entered : %lg\n",val);
  
  reci=1/val;
  
  printf("The reciprocal of %lg is %lg\n",val,reci);
  
      
  system("PAUSE");
  return 0;
}

