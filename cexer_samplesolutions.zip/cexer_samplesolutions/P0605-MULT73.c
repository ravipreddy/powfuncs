/*
P0605 : MULT73.C � Multiples of 7
[Learning Goal : Simple looping]
Write a program to print all multiples of 7 which are greater than 100 and less than 150.
*/

#include<stdio.h>
#include<stdlib.h>

int main()

{
    int myNum=0,i=1;
    
    while(1)
    {
		myNum=7*i;
		if(myNum>100 && myNum<150)
		 printf("%2d Multiple of 7 is %3d and is in Range 100-150  \n",i,myNum);
		else if (myNum>150) 
		 break;
		i++;
        
    }

    system("PAUSE");
    return 0;
}

