/*
P0910 : MULTIPLE.C � Check for Multiple
[Learning Goal : Writing User Defined Functions]
Write a function
int ismultof7(int n)
which will return 1 if n is a multiple of 7 and 0 otherwise
*/

#include<stdio.h>
#include<stdlib.h>
int ismultof7(int n);

int main()

{
	int myNum=0;
	
	printf("Enter the value >> ");
	scanf("%d",&myNum);
	
	if(ismultof7(myNum))
	{
		printf("The number %d is multiple of 7\n",myNum);
	}
	else
	  printf("The number %d is NOT a multiple of 7\n",myNum);
	


    system("PAUSE");
    return 0;
}
int ismultof7(int n)
{
	if(n%7==0)
	  return 1;
	else
	  return 0;  
	
}

