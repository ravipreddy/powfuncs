/*
P1402 : STRDUP.C � String Duplicate Function
[Learning Goal : Using Dynamic Memory Allocation]
Write a program using a user defined function which returns a duplicate copy of the string
passed as an argument.
char * my_strdup (char *str);
*/

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

char * my_strdup (char *str);

int main()

{
	char str[100];
    printf("Enter the String >> ");
    gets(str);
    
    
    char* cpystr = my_strdup (str);
    printf("After copy  string is %s\n", cpystr);

    system("PAUSE");
    return 0;
}

char * my_strdup (char *str)
{
	char *p = (char*)malloc(strlen(str) + 1);
    if (p != NULL)
    strcpy (p,str);
    return p;
}

