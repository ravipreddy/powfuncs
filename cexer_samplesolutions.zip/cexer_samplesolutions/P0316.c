/*
P0316 : DOZENS.C � Counting Eggs
[Learning Goal : arithmetic, modulus operator]
Given the number of eggs in a basket, print the value in dozens of eggs.
For example, 38 eggs is "3 dozens and 2 eggs", 18 eggs is "1 dozens and 6 eggs", and so
on.
*/
#include<stdio.h>
#include<stdlib.h>

int main()

{

  int numEggs=0,dozenEgg=0 , resEgg=0;
  
  
  
  printf("Enter  the Number of Eggs in Basket  >>");
  scanf("%d",&numEggs);
  printf("You have entered : %d\n",numEggs);
  
  
  
  dozenEgg=numEggs/12;
  resEgg=numEggs%12;
  
  
  
  printf("The %d Egg means %d dozen and %d Eggs\n",numEggs,dozenEgg,resEgg);
  
      
  system("PAUSE");
  return 0;
}

