/*
P0620 : DIV13.C � Writing Octal Equivalent
[Learning Goal : Simple logic, octal format output]
Write a program to print the octal equivalent of a given positive integer.
*/

#include<stdio.h>
#include<stdlib.h>

int main()

{
	int myNum=0,c=0,temp=0;
	
	printf("Enter an integer value >> ");
    scanf("%d",&myNum);
    
    printf("The Octal Equivalent of %d is %o\n",myNum,myNum);


    system("PAUSE");
    return 0;
}

