/*
P0623 : DIV13.C � Sum of Even Numbers
[Learning Goal : Simple looping]
Write a program to find the sum of first n even numbers
*/

#include<stdio.h>
#include<stdlib.h>

int main()

{

	int myNum=0,sum=0,i=1,even;

	printf("How many even numbers to be added >> ");
    scanf("%d",&myNum);
    i=0;
    printf("Adding ");
    while(i<myNum)
    {
        even = 2*(i+1);
        printf("%d ",even);
    	sum += even;
    	i++;
	}

	printf("\n\nSum of first %d even numbers is %d\n",myNum,sum);



    system("PAUSE");
    return 0;
}

