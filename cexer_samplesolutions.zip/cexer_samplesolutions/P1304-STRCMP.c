/*
P1304 : STRCMP.C � String Comparison
[Learning Goal : Using Pointers]
Write a program using a user defined function for performing string comparison.
int my_strcmp(char *s1, char *s2);

*/

#include<stdio.h>
#include<stdlib.h>
int my_strcmp(char *s1, char *s2);

int main()

{
	char myChar[100],myChar2[100];
	
	printf("Enter the String 1 >> ");
	gets(myChar);
	
	printf("Enter the String 2 >> ");
	gets(myChar2);
	
	if(my_strcmp(myChar,myChar2)==1)
	 printf("The string %s and %s are identical\n",myChar,myChar2);
	else
	 printf("The string %s and %s are Not identical\n",myChar,myChar2);
	 


    system("PAUSE");
    return 0;
}
int my_strcmp(char *s1, char *s2)
{
	int i=0,j=0;
	while(s1[i]!='\0')
	 i++;
	while(s2[j]!='\0')
	 j++;
	
	if(i!=j)
	 return 0;
	else
	  i=j=0;
	
	while(s1[i]!='\0')
	{
	  if(s1[i]!=s2[i])
	    return 0;
	  i++; 		
	} 
	
	return 1;   
}
