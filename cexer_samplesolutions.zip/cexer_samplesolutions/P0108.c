#include<stdio.h>
#include<stdlib.h>

int main()

{

  printf("size of long double is %d bytes\n",sizeof(long double));
  printf("size of double is %d bytes\n",sizeof(double));
  printf("size of float is %d bytes\n",sizeof(float));
  printf("size of long is %d bytes\n",sizeof(long));
  printf("size of int is %d bytes\n",sizeof(int));
  printf("size of short is %d bytes\n",sizeof(short));
  printf("size of char is %d bytes\n",sizeof(char));
  
  system("PAUSE");
  return 0;
}


