/*
P1111 : PALIND.C � Palindrome Words
[Learning Goal : Working with Strings]
Write a program which takes one word as input and checks whether or not it is a palindrome.
*/

#include<stdio.h>
#include<stdlib.h>
int is_palindrome(char str[]);

int main()

{
	char myChar[100];
	int flag=0;
	
	printf("Enter a string >> ");
	gets(myChar);
    
    flag=is_palindrome(myChar);
    
    if(flag==1)
      printf("The string is palindrome\n");
    else
	  printf("The string is not palindrome\n");  

    system("PAUSE");
    return 0;
}
int is_palindrome(char str[])
{
char tmp;
int i=0,len=0,half=0,flag=1;

for(i=0;str[i]!='\0';i++)
   len++;

half=len/2;

for(i=0;i<half;i++)
   {
   if(str[len-i-1]!=str[i])
     {
     flag=0;
     break;
     }
   }
return flag;
}


