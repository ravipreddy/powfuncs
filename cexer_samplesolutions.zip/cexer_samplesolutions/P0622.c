/*
P0622 : DIV13.C � Sum of Integers
[Learning Goal : Simple looping]
Write a program to print the sum of all positive integers from 1 to n where n is entered by the
user.

*/

#include<stdio.h>
#include<stdlib.h>

int main()

{
	int myNum=0,sum=0,i=1;
	
	printf("Enter an integer value >> ");
    scanf("%d",&myNum);
    
    while(i<=myNum)
    {
    	sum=sum+i;
    	i++;
	}
	
	printf("Sum of integer from 1 to %d is %d\n",myNum,sum);


    system("PAUSE");
    return 0;
}

