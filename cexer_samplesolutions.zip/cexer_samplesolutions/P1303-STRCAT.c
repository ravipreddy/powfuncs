/*
P1303 : STRCAT.C � String Concatenation
[Learning Goal : Using Pointers]
Write a program using a user defined function for performing string concatenation.
void my_strcat(char * s1, char * s2)
*/

#include<stdio.h>
#include<stdlib.h>
void my_strcat(char * s1, char * s2);
int main()

{
	char myChar[100],myChar2[100];
	
	printf("Enter the String 1 >> ");
	gets(myChar);
	
	printf("Enter the String 2 >> ");
	gets(myChar2);
	
	my_strcat(myChar,myChar2);
	
	printf("String 1 is concataned to String 2 and is %s\n",myChar2);


    system("PAUSE");
    return 0;
}
void my_strcat(char *s1, char *s2)
{
	int i=0,j=0;
	while (s2[j]!='\0')
	   j++;
	   
	while(s1[i]!='\0')
	  {
	  	s2[j]=s1[i];
	  	i++;
	  	j++;
	  }   
	
	s2[j]='\0';
	
	return;
}
