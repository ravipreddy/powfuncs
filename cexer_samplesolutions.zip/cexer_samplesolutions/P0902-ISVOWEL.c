/*
P0902 : ISVOWEL.C � Vowels Check
[Learning Goal : Writing User Defined Functions]
Write a program which contains a user defined function is_vowel with the following function
prototype.
int is_vowel (char p);
The function returns 1 is the character is a lowercase of uppercase vowel, else it returns 0.

*/

#include<stdio.h>
#include<stdlib.h>
int is_vowel (char p);
int main()

{ 
    char myChar=NULL;
    
    printf("Enter a Character >>");
    scanf("%c",&myChar);
    
    printf("Value >>%d\n",is_vowel(myChar));
    
    


    system("PAUSE");
    return 0;
}
int is_vowel (char p)
{
	if(p=='a'|| p=='A'|| p=='e'|| p=='E'|| p=='i'|| p=='I'|| p=='o'|| p=='O'|| p=='u'|| p=='U' )
	 return 1;
	else
	 return 0;
	
}

