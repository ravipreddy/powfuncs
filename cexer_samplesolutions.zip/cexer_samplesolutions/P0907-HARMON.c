/*
P0907 : HARMON.C � Harmonic Series
[Learning Goal : Writing User Defined Functions]
Write a program which contains a user defined function harmonic with the following function
prototype.
double harmonic (int n);
which returns the partial sum of the harmonic series up to N terms
1 + 1/1 + 1/2 + 1/3 + 1/4 + ... + 1/N

*/


#include<stdio.h>
#include<stdlib.h>
double harmonic (int n);

int main()

{
	int myNum=0;
	printf("Enter the integer value >> ");
	scanf("%d",&myNum);
	
	printf("The harmonic sum of series up to %d is %lg\n",myNum,harmonic(myNum));


    system("PAUSE");
    return 0;
}
double harmonic (int n)
{
	int i=1;
	double sum=1.0;
	while(i<=n)
	 {
	 	sum=sum+(1.0/i);
	 	i++;
	 }
	 
	 return sum;
}

