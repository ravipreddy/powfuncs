/*
P1008 : GRADES.C � Letter Grade Computation
[Learning Goal : Using One Dimensional Arrays]
Write a program which uses the functions average and stddev developed in P1002 and
calculates the letter grades for a set of marks read from a file marks.txt. The letter grade is
based on "normalized score" defined below:
S = normalized score = (marks � average)/stddev
and letter grade is assigned as follows:
A if S ? 1.5
B if 1.5 > S ? 0.5
C if 0.5 > S ? -0.5
D if -0.5 > S ? -1.5
F if -1.5 > S

*/

#include<stdio.h>
#include<stdlib.h>
#include<math.h>

double average(double x[], int n);
double stddev(double x[], int n);

int main()

{
	FILE *fptr;
    char fileName[100],grade; ;
    double myNum[100],avg=0.0,std=0.0,score=0.0;
    int i=0,count=0,sumOdd=0,sumEven=0;
    
    
    printf("Enter the file(marks.txt) to be opened >>");
    gets(fileName);
    
    
    fptr=fopen(fileName,"r");
    
    while(!feof(fptr))
        {
        fscanf(fptr,"%lg",&myNum[i]);
        count++;
        i++;
        }
        
    printf("The total number of Score is %d\n",count);
    
    avg=average(myNum,count);
    std=stddev(myNum,count);
    
    printf("Average %lg\n",avg);
    printf("Std Dev %lg\n",std);
    
    printf(" SCORE\tNORMAL SCORE\tGRADE\n");
    rewind(fptr);
    while(!feof(fptr))
        {
        fscanf(fptr,"%lg",&myNum[i]);
        
        score=(myNum[i]-avg)/std;
        
           
        if(score >=1.5)
           grade='A';
           
        else if(score < 1.5 && score>=.5)
           grade='B';
           
		else if(score>.5 || score >= -0.5)
           grade='C';
           
		else if(score> -0.5 || score >=-1.5)
           grade='D'; 
		    
		else if(score>=-1.5)
           grade='F'; 
		            
        printf(" %lg\t  %lg\t   %c\n",myNum[i],score,grade);
        score=0.0;
        i++;
        }
    
    


    system("PAUSE");
    return 0;
}

double average(double x[], int n)
{
	int i=0;
	double avg=0.0,sum=0.0;
	for(i=0;i<n;i++)
	   sum=sum+x[i];
	avg=sum/n;
	return avg;
}


double stddev(double x[], int n)
{
	int i=0;
	double std=0.0, avg=0.0,sum=0.0,ssum=0.0;
	
	for(i=0;i<n;i++)
	   sum=sum+x[i];
	
	avg=sum/n;
	
	for(i=0;i<n;i++)
    	ssum=ssum+(x[i]- avg)*(x[i]- avg);
	

	std=ssum/(n-1);
	std=sqrt(std);
	
	
	return std;
	
}

