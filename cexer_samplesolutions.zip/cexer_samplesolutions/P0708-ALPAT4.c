/*
P0708 : ALPAT4.C � Alphabetic Pattern 4
[Learning Goal : Nested Looping]
Write a program to generate a square using characters given an integer N. 

Input size n >> 6
abcdef
a    f
a    f
a    f
a    f
abcdef
*/

#include<stdio.h>
#include<stdlib.h>

int main()

{
	int myNum=0,i=0,j=0,k=0;
	
	printf("Enter the positive Number >> ");
	scanf("%d",&myNum);
	
	for(i=0;i<myNum;i++)
	{
		for (j=0;j<myNum;j++)
		{
			if(i==0 || i==myNum-1 || j==0 || j==myNum-1)
			  printf("%c",'a'+j);
			else
			  printf(" ");
		}
		
		printf("\n");
		
	}



    system("PAUSE");
    return 0;
}

