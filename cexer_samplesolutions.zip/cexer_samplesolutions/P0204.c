#include<stdio.h>
#include<stdlib.h>

int main()

{

  int myNum;
  printf(" Please Enter a Value [ 0 to 255 Only] >> ");
  scanf("%d",&myNum);
  printf("Character Equivalent of [%d] is [%c]\n",myNum,myNum);
  
  
  system("PAUSE");
  return 0;
}

