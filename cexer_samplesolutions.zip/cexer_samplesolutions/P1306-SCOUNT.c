/*
P1306 : SCOUNT.C � Substring Count Function
[Learning Goal : Using Pointers]
Write a function that accepts a string and determines the number of times a given substring
appears in it. For example, if the string is "Malayalam", and the search substring is "al", your
program should print the value 2.
int my_strstr_count(char *str, char *substr);
*/

#include<stdio.h>
#include<stdlib.h>

int my_strstr_count(char *str, char *substr);

int main()

{
	char myChar[100],charS[100];
	
	printf("Enter the String >> ");
	gets(myChar);
	
	printf("Enter the string your want to count >> ");
	gets(charS);
	
	printf("The count of [%s] in [%s] is %d\n",charS,myChar,my_strstr_count(myChar,charS));


    system("PAUSE");
    return 0;
}


int my_strstr_count(char *str, char *substr)
{
	int count=0,i=0,j=0,k=0,status=0,length=0;
	
	while(substr[length]!='\0')
	 length++;
	
	
	while(str[i]!='\0')
	{
		if(str[i]==substr[j])
		{
		  for(k=0;k<length;k++)
		  {
		  	if(str[i+k]==substr[j+k])
		  	  status=1;
			else
			{
				status=0;	
				break;
			}
			  	  	  
		  }	
		}
	   	
	   if(status==1)
	   {
	   	count++;
	   	status=0;
	   }
	     
		
		i++;
	}
	
	return count;
}

