/*
P1005 : REVARR1.C � Reversing an array of values
[Learning Goal : Using One Dimensional Arrays]
Write a program to reverse the sequence of elements in an integer array. Use a function
rev_array with prototype given below:
void rev_array(int n, int arr[]);
*/

#include<stdio.h>
#include<stdlib.h>

void rev_array(int n, int arr[]);

int main()

{
	int array[]={1,3,5,2,9,10},items=0,i=0;
    
    items=sizeof(array)/sizeof(int);
    
    printf("\nOriginal Array ") ; 	
	for(i=0;i<items;i++)
	  	printf("%d ",array[i]);
    
    rev_array(items,array);
    
    printf("\nReverse Array ") ;   	
	for(i=0;i<items;i++)
	 	printf("%d ",array[i]);
    
    
    printf("\n");
    system("PAUSE");
    return 0;
}

void rev_array(int n, int arr[])
{
	int i=0,revArr[n],temp=0;
	
		  	
	for(i=0;i<n/2;i++)
	{
	  temp=arr[i];
	  arr[i]=arr[n-1-i];
	  arr[n-1-i]=temp;	
	}
	   
	
	 
}
