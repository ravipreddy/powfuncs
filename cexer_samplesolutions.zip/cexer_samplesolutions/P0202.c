#include<stdio.h>
#include<stdlib.h>

int main()

{

  float myFloat;
  printf(" Please Enter an Float Value >> ");
  scanf("%f",&myFloat);
  printf("You have entered :%f\n",myFloat);
  printf("You have entered :%g\n",myFloat);
  printf("You have entered :%e\n",myFloat);
  
  system("PAUSE");
  return 0;
}

