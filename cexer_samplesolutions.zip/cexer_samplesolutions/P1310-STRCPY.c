/*
P1310 : STRCPY.C � String Copy Function
[Learning Goal : Using Pointers]
Write a program using a user defined function for reversing a string.
char * strrev(char * s);
*/

#include<stdio.h>
#include<stdlib.h>

char * strrev(char * str);

int main()

{
	char myChar[100];
	
	printf("Enter the String Only >> ");
	gets(myChar);
	
	printf("The Entered string is %s \n",myChar);
	
	
	
	printf("The reverse of the string is [%s]\n",strrev(myChar));


    system("PAUSE");
    return 0;
}

char* strrev(char *str)
{
	char tmp;
	
	int i=0,len=0,half=0;
      for(i=0;str[i]!='\0';i++)
        len++;
    half=len/2;
      for(i=0;i<half;i++)
      {
        tmp=str[len-i-1];
        str[len-i-1]=str[i];
        str[i]=tmp;
      }
      
    return str;
}

