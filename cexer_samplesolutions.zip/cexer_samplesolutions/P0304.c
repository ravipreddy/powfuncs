/*
P0304 : TRUNC.C � Integer Truncation
[Learning Goal : integer arithmetic, truncation]
Read in a decimal value given by user, assign it to an integer variable and print the result.
Try various positive and negative values for the input value of variable p. See what is the
effect of this decimal-to-integer conversion.
Code fragment:
int k;
float p;
user enters value of p here
print out value of p here
k = p;
print out value of k
Hint: When a decimal value is assigned to an int variable, the fractional part is truncated and
only the whole number part is assigned to the int variable.

*/

#include<stdio.h>
#include<stdlib.h>


int main()

{

  int k=0;
  float p=0.0;
  
  
  printf("Enter value for p >>");
  scanf("%f",&p);
  printf("You have entered : %g\n",p);
  
  k=p;
  
  printf("Your value is stored as %d\n",k);
  
     
  system("PAUSE");
  return 0;
}

