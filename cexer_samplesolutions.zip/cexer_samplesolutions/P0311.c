/*
P0311 : SPHERE.C � Sphere Geometry
[Learning Goal : arithmetic, io]
Given the radius of a sphere entered by the user, compute and display the diameter, volume
and surface area of the sphere.
NOTE: Declare and use a symbolic constant PIVALUE for this
#define PIVALUE 3.141592
*/

#include<stdio.h>
#include<stdlib.h>
#define PIVALUE 3.141592

int main()

{

  float radius=0.0,sArea=0.0, vol=0.0,dia=0.0;
  
  
  printf("Enter  value for radius of Sphere >>");
  scanf("%f",&radius);
  printf("You have entered : %g\n",radius);
  
  dia=2*radius;
  vol=(4.0/3)*PIVALUE*radius*radius*radius;
  sArea=4*PIVALUE*radius*radius;
  
  printf("The diameter of the Sphere of radius %g is %g\n",radius,dia);
  printf("The volume of the Sphere of radius %g is %g\n",radius,vol);
  printf("The surface area of the Sphere of radius %g is %g\n",radius,sArea);
  
      
  system("PAUSE");
  return 0;
}

