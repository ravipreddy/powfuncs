/*
P0301 : DIVIDE.C � Integer Division
[Learning Goal : integer division]
Read in two integer values j and k entered by the user and print out the quotient j/k and the
remainder j%k.
Run your program for the following cases:
(a) Both inputs are positive integers
(b) Both inputs are negative integers
(c) One is positive and the other is negative.
*/
#include<stdio.h>
#include<stdlib.h>


int main()

{

  int j=0,k=0;
  int result1=0,result2=0;
  
  printf("Enter value for j >>");
  scanf("%d",&j);
  printf("You have entered : %d\n",j);
  
  printf("Enter value for k >>");
  scanf("%d",&k);
  printf("You have entered :%d\n",k);
  
  result1=j/k;
  result2=j%k;
  
  printf("Result of j/k is %d\n",result1);
  printf("Result of j%%k is %d\n",result2);
  
  system("PAUSE");
  return 0;
}

