/*
P1703 : COMPLEX.C � Complex Numbers
[Learning Goal : Using Structures]
Define a struct with following members to store a complex number of the form a+ib where a is
the real part and b is the imaginary part.
double re;// real part
double im;// imaginary part
Write a program to take two complex numbers given by the user and print their sum and
product. You will need to write separate functions for the sum and product.

*/

#include<stdio.h>
#include<stdlib.h>

typedef struct
{
	double re;// real part
    double im;// imaginary part
	
}complex;

complex add(complex n1,complex n2);
complex mlt(complex n1, complex n2);


int main()

{
	complex n1, n2, temp;

    printf("For 1st complex number \n");
    printf("Enter real part >> ");
    scanf("%lg", &n1.re);
    printf("Enter imaginary part >> ");
    scanf("%lg", &n1.im);

    printf("\nFor 2nd complex number \n");
    printf("Enter real part >> ");
    scanf("%lg", &n2.re);
    printf("Enter imaginary part >> ");
    scanf("%lg", &n2.im);

    

    temp = add(n1, n2);
    printf("\nSum = %.1f + %.1fi \n", temp.re, temp.im);

    temp = mlt(n1, n2);
    printf("\nProduct = %.1f + %.1fi\n", temp.re, temp.im);

    system("PAUSE");
    return 0;
}

complex add(complex n1,complex n2)
{
    complex temp;

    temp.re = n1.re + n2.re;
    temp.im = n1.im + n2.im;

    return temp ;
	
}

complex mlt(complex n1, complex n2)
{
	complex temp;

      temp.re = (n1.re * n2.re) - (n1.im * n2.im);
      temp.im = (n1.re * n2.im) + (n1.im * n2.re);

      return temp;

	
}
