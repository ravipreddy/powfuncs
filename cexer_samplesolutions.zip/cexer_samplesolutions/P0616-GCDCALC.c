/*
P0616 : GCDCALC.C Computing GCD and LCM of Two Integers
[Learning Goal : Simple looping, conditional termination of loop]
The Greatest Common Divisor of two positive integers can be calculated iteratively by the
following formula known as Euclid's algorithm. You can see that this is a recursive definition
with GCD(m,n) defined in terms of GCD(n,m%n).
GCD(m,n) = GCD (n,m) if n>m
= m, if n=0
= GCD(n, m%n) otherwise
We can also compute the Least Common Multiple of the two integers by using the following
relation between the GCD and the LCM.
LCM * GCD = m * n
Write a program GCDCALC.C using Euclid's algorithm to compute the GCD and the LCM of
two integers input by the user.
*/

#include<stdio.h>
#include<stdlib.h>

int main()

{
    int m=0,n=0,lcm=0,gcd=0,bigNum=0,smallNum=0,temp=0;
    
    printf("Enter the first number >> ");
    scanf("%d",&m);
    
    printf("Enter the second number >> ");
    scanf("%d",&n);
    
    if(n==0 || m==0)
        {
        printf("\nERROR: One of the values equals 0.\n");
        system("PAUSE");
        exit(0);
        }
        
    if(n>=m)
	{
	  bigNum=n;
	  smallNum=m;
	 } 
	else
	{
	  bigNum=m;
	  smallNum=n;	
	}
	while(smallNum!=0)
	{
		temp=bigNum%smallNum;
		bigNum=smallNum;
		smallNum=temp;
		
	}
    gcd=bigNum;
    lcm=(m*n)/gcd;
	
	printf("The GCD of %d and %d is %d\n",n,m,gcd);
	printf("The LCM of %d and %d is %d\n",n,m,lcm);     
    

    system("PAUSE");
    return 0;
}

