/*
P0706 : ALPAT3.C � Alphabetic Pattern 3
[Learning Goal : Nested Looping]
Write a program which, given an integer n as input, generates a pyramid of n lines using
characters. The output for n=2 and 4 are shown below as examples. 
Input size n >> 2
a
bc
*/

#include<stdio.h>
#include<stdlib.h>

int main()

{
	int myNum=0,i=0,j=0,k=0;
	
	printf("Enter the positive Number >> ");
	scanf("%d",&myNum);
	
	for(i=0;i<myNum;i++)
	{
		for (j=0;j<i+1;j++)
		{
			printf("%c",'a'+i+j);
		}
		
		printf("\n");
		
	}

    system("PAUSE");
    return 0;
}

