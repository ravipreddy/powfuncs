/*
P0506 : DISCOUNT.C � Computing discount
[Learning Goal : Simple comparisons]
A company gives festival discount on purchase of their products in the following
percentages:
(i) if purchase amount < 1500 then 5% discount.
(ii) If purchase amount >= 1500 but < 3500 then 10% discount.
(iii) If purchase amount >= 3500 but < 5000 then 12% discount.
(iv) If purchase amount > 5000 then 15% discount.
Write a C program using nested if statement to compute the amount to be paid by the
customer after discount.
*/
#include<stdio.h>
#include<stdlib.h>

int main()

{
  int pAmount=0;
  double amount=0.0;
  	
  printf("Enter the Purchase Amount >> ");
  scanf("%d",&pAmount);
  
  if(pAmount<1500)
   amount=pAmount-pAmount*.05;
  else if(pAmount>=1500 && pAmount<3500)
   amount=pAmount-pAmount*.1;
  else if(pAmount>=3500 && pAmount<5000)
   amount=pAmount-pAmount*.12;
  else
   amount=pAmount-pAmount*.15;
  
  printf("The amount to be paid for Purchase of Products of Worth %d is %g\n",pAmount,amount);

  system("PAUSE");
  return 0;
}

