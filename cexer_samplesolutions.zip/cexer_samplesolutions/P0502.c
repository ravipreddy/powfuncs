/*
P0502 : MIN2.C � Print smallest integer
[Learning Goal : Simple comparisons]
Write a program to accept three integers entered by the user and print out the smallest of the
three numbers.
*/
#include<stdio.h>
#include<stdlib.h>

int main()

{
	int myNum1=0,myNum2=0,myNum3=0;

    printf("Enter first integer number >> ");
    scanf("%d",&myNum1);

    printf("Enter second integer number >> ");
    scanf("%d",&myNum2);

    printf("Enter third integer number >> ");
    scanf("%d",&myNum3);

    printf("Out of %d, %d and %d the smallest number is ",myNum1,myNum2,myNum3);

    if(myNum1<=myNum2 && myNum1<=myNum3)
        printf("%d\n",myNum1);
    else if(myNum2<=myNum1 && myNum1<=myNum3)
        printf("%d\n",myNum2);
    else
        printf("%d\n",myNum3);

  return 0;
}

