/*
P1012 : LEFTROT.C � Array Rotation
[Learning Goal : Using One Dimensional Arrays]
Write a function to left rotate the elements of an integer array by one place.
void left_rotate(int * arr, int arrsize);
The original array of [1,2,3,4,5,6] becomes [2,3,4,5,6,1]. Do not make a copy of the array. 
*/

#include<stdio.h>
#include<stdlib.h>

void left_rotate(int * arr, int arrsize);

int main()

{
	int count=0,i=0;
	int array[count];
	
	printf("Enter the value of Element in array >>");
	scanf("%d",&count);
	
	for(i=0;i<count;i++)
	{
		printf("Enter the %d element for integer array >> ",i+1);
		scanf("%d",&array[i]);
	}
	
	printf("Befor  Rotation the Array is\n");
    for(i=0;i<count;i++)
	{
		printf("%d\t",array[i]);
		
	}
    
    left_rotate(array, count);
    
    
    printf("\nAfter Rotation the Array is\n");
    
    for(i=0;i<count;i++)
	{
		printf("%d\t",array[i]);
		
	}

    printf("\n");
	system("PAUSE");
    return 0;
}
void left_rotate(int * arr, int arrsize)
{
	int i=0,temp;
	temp=arr[i];
	for(i=0;i<arrsize-1;i++)
	{
	  arr[i]=arr[i+1];	
	}
	arr[arrsize-1]=temp;
	
	}

