/*
P0803 : NOSPAC.C � Remove Spaces in Text
[Learning Goal : Sequential Fie IO]
Write a program which will display the contents of a file on the monitor while removing all
spaces from the text.

*/

#include<stdio.h>
#include<stdlib.h>

int main()

{
	FILE *fptr;

    char fileName[100], myChar;

    printf("Enter the filename (remo.txt) to open >> ");
    scanf("%s", fileName);
    

    fptr = fopen(fileName, "r");
    if (fptr == NULL)
    {
        printf("Cannot open file \n");
        exit(0);
    }

   
    do
	{
        myChar = fgetc(fptr);
        if(myChar==' ')
         continue;
		printf ("%c", myChar);        
    }while (myChar != EOF); 

    fclose(fptr);
    printf("\n");


    system("PAUSE");
    return 0;
}

