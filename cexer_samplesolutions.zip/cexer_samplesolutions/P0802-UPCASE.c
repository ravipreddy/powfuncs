/*
P0802 : UPCASE.C � Convert to Uppercase
[Learning Goal : Sequential Fie IO]
Write a program which will convert the text in one file to uppercase and store in another file.
It will also display the text on the monitor.

*/

#include<stdio.h>
#include<stdlib.h>
#include<ctype.h>

int main()

{
	FILE *fptr,*cptr;

    char fileName[100],fileCopy[100], myChar,myChar2;

    printf("Enter the filename (remo.txt) to open >> ");
    scanf("%s", fileName);

    fptr = fopen(fileName, "r");
    if (fptr == NULL)
    {
        printf("Cannot open file \n");
        exit(0);
    }
    
    printf("Enter the filename to copy  >> ");
    scanf("%s", fileCopy);
    
    cptr = fopen(fileCopy, "w");
    
    while ((myChar = fgetc(fptr)) != EOF)
	{
        
        fputc(toupper(myChar),cptr);
		     
    }
    
    fclose(fptr);
	fclose(cptr);
    
    cptr = fopen(fileCopy, "r");
	
	do
	{
        myChar = fgetc(cptr);
		printf ("%c", myChar);        
    }while (myChar!=EOF); 
    
    fclose(cptr);
    printf("\n");


    system("PAUSE");
    return 0;
}

