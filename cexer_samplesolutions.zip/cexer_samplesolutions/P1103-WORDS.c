/*
P1103 : WORDS.C � Capitalize Words
[Learning Goal : Working with Strings]
Write a program which takes in a line of text entered by the user and converts the first
character of each word to uppercase. The remaining letters remain unchanged.
*/

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int main()

{
	char myChar[100],copyText[100];
	int i=0,j=-1;
	
	printf("Enter a line of text >> ");
	gets(myChar);
	
	while(myChar[i]!='\0')
	{
		
		
		if(isgraph(myChar[i]) && !isgraph(myChar[j]))		  
		  myChar[i]=toupper(myChar[i]);

        else
		  myChar[i]=(myChar[i]);		
		
		i++; 
		j++;
		
		
	}
   
   printf("The Modified String is [%s] \n",myChar);


    system("PAUSE");
    return 0;
}

