#include<stdio.h>
#include<stdlib.h>

int main()

{

  printf("Hello World \a\a\n");
  system("PAUSE");
  return 0;
}

