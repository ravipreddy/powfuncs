#include<stdio.h>
#include<stdlib.h>

#define PI 3.141592

int main()

{

  printf("Value of PI is %f\n",PI);
  
  system("PAUSE");
  return 0;
}



