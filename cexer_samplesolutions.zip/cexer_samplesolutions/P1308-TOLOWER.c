/*
P1308 : TOLOWER.C � Changing to Lowercase
[Learning Goal : Using Pointers]
Write a program using a user defined function for converting a string to lower case letters.
void strtolower(char * s);

*/

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

void strtolower(char * s);

int main()

{
	char myChar[100];
	
	printf("Enter the String in Upper Case Only >> ");
	gets(myChar);
	
	printf("The Entered string is %s \n",myChar);

	
	strtolower(myChar);
	
	printf("The lower version of the string is %s \n",myChar);


    system("PAUSE");
    return 0;
}

void strtolower(char * s)
{
	int i=0;
	while(s[i]!='\0')
	{
	 if(isalpha(s[i]) && s[i]>='A' && s[i]<='Z')// intro to isalpha() function purpose
	 {
	 	s[i]=s[i]+32;
	    i++;
	 }
	 else
	 {
	 	s[i]=s[i];
	 	i++;
	 }
	   
	}
	return ;
}
