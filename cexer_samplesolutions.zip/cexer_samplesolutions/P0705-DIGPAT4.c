/*
P0705 : DIGPAT4.C � Digit Pattern 4
[Learning Goal : Nested Looping]
Write a program which, given an integer n as input, generates a pyramid of n lines. The
output for n=1, 2, 3 and 5 are shown below as examples. 
Input size n >> 3
 3
303
33333
*/

#include<stdio.h>
#include<stdlib.h>

int main()

{
	int myNum=0,i=0,j=0,k=0;
	
	printf("Enter the positive Number >> ");
	scanf("%d",&myNum);
	
	for(i=0;i<myNum;i++)
	{
		for (j=0;j<myNum-i-1;j++)
		{
			printf("%c",' ');
		}
		
		for(k=0;k<(i*2)+1;k++)
		  {
		  	if(i+1==myNum || k==i*2 || k==0)
                printf("%d",myNum);
            else
                printf("%d",0);

		  }
		printf("\n");
	}




    system("PAUSE");
    return 0;
}

