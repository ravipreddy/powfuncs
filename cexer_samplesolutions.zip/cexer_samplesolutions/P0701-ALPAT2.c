/*
P0701 : ALPAT2.C � Alphabetic Pattern 1
[Learning Goal : Nested Looping]
Write a program which, given an integer n as input, generates a square made of characters
as shown in the examples below.
Input size n >> 4
abcd
a**d
a**d
abcd

*/

#include<stdio.h>
#include<stdlib.h>

int main()

{
	int myNum=0,i=0,j=0;
	
	printf("Enter an integer value >> ");
	scanf("%d",&myNum);
	
	for(j=0;j<myNum;j++)
	{
	  for(i=0;i<myNum;i++)
	  {
	    if(j==0 || j==myNum-1 || i==0 || i==myNum-1)
		  printf("%2c",97+i);
		else
		  printf("%2c",'*');
	  
	  }
	  printf("\n");
	}


    system("PAUSE");
    return 0;
}

