/*
P1011 : POLYMULT.C � Polynomial Multiplication
[Learning Goal : Using One Dimensional Arrays]
A real polynomial P(x) of degree n or less is given by
P(x)=a0+a1x+a2x2+����+anxn
The coefficients of the polynomial can be stored as an array. Write a function for multiplying
two polynomials where all the coefficients are integers. n1 and n2 are number of coefficients
in p1 and p2, respectively.
void prodpoly(int n1, int n2, int p1[], int p2[], int pprod[]);
*/

#include<stdio.h>
#include<stdlib.h>

void prodpoly(int n1, int n2, int p1[], int p2[], int pprod[]);


int main()

{
	int size1=0,size2=0,size3=0;
	int poly1[]={1,2,-1,2}; 
	int poly2[]={2,-1,1,3};
	
	int pprod[7],i=0;
	
	
	size1=sizeof(poly1)/sizeof(int);
	size2=sizeof(poly2)/sizeof(int);
	size3=size1+size2-1;
	
	printf("The coeff of poly1 are\n");
	
	for(i=0;i<size1;i++)
	  printf("%d\t",poly1[i]);
	
	printf("\nThe coeff of poly2 are\n");
	  
	for(i=0;i<size2;i++)
	  printf("%d\t",poly2[i]);  
	
	//fflush(stdout);
	prodpoly(size1,size2,poly1,poly2,pprod);
	
	
		
	printf("\nThe coeff of poly3 are\n");
	  
	  
	for(i=0;i<size3;i++)
	  printf("%d\t",pprod[i]);  

    printf("\n");
    system("PAUSE");
    return 0;
}

void prodpoly(int n1,int n2,int p1[],int p2[],int pprod1[])
{
	int i=0,j=0;
	
	
	for(i=0;i<n1+n2-1;i++)
	  pprod1[i]=0;
	  
	printf("\nThe coeff of 1 are\n");
	
	for(i=0;i<n1;i++)
	  printf("%d\t",p1[i]);
	
	printf("\nThe coeff of 2 are\n");
	  
	  
	for(i=0;i<n2;i++)
	  printf("%d\t",p2[i]);  
	  

    for(i=0;i<n1;i++)
    for(j=0;j<n2;j++)
    {
    	
		pprod1[i+j]=pprod1[i+j]+p1[i]*p2[j];
    	//printf("\n%d %d %d  %d %d %d",i,j,i+j,p1[i],p2[j],pprod1[i+j]);
	}
     
}


