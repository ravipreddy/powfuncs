/*
P0318 : TIME.C � Time Conversion
[Learning Goal : arithmetic, modulus operator, integer truncation]
Given the time duration of an event in hours (decimal value), print it in terms of hours,
minutes and seconds.
SAMPLE SESSION #01
Enter time in hours : 12.43767
The time equals 12 hours, 26 minutes and 15.612 seconds
*/

#include<stdio.h>
#include<stdlib.h>


int main()

{

  int hour=0;
  double time=0.0,second=0.0,minutes=0.0;
   
  
  printf("Enter  the time in hours  >>");
  scanf("%lf",&time);
  printf("You have entered : %lf\n",time);
  
    
  hour=(int)time;
  minutes=(time-(int)time)*60;
  second=(minutes-(int)minutes)*60;
   
  printf("\nThe time %g is equal to %d hours %d minutes %g seconds\n",  time,hour,(int)minutes,second);    
  
  system("PAUSE");
  return 0;
}

