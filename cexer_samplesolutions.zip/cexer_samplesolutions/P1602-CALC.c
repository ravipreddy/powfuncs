/*
P1602 : CALC.C � Simple Calculator
[Learning Goal : Using Command Line Arguments]
Write a program to take 2 integer values separated by an arithmetic operator. The program
should print the result. The operator can be any one from +, -, *, / and %.
c:\ calc 3 + 5
Result = 8
c:\ calc 3 * -5
Result = -15

*/

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int main(int argc, char * argv[])

{
	int a=0,b=0,i=0;


	a=atoi(argv[1]);
    b=atoi(argv[3]);

    printf("Inputs are is [%s] [%s] [%s]\n",argv[1],argv[2],argv[3]);

    if(!strcmp(argv[2],"+"))
      printf("Result : %d\n",(a+b));
    else if(!strcmp(argv[2],"-"))
      printf("Result : %d\n",(a-b));
    else if(!strcmp(argv[2],"x"))
      printf("Result : %d\n",(a*b));
    else if(!strcmp(argv[2],"/"))
      printf("Result : %d\n",(a/b));
	else if(!strcmp(argv[2],"%"))
      printf("Result : %d\n",(a%b));
    else
	 printf("Please use '+', '-', 'x', '/' & '%%' operators only.\n");




    system("PAUSE");
    return 0;
}

