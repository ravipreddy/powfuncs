#include<stdio.h>
#include<stdlib.h>

int main()

{

  int myNum;
  printf(" Please Enter an integer Value >> ");
  scanf("%d",&myNum);
  printf("You have entered :%d\n",myNum);
  
  system("PAUSE");
  return 0;
}

