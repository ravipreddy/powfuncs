/*
P0625 : DIV13.C � Computing Sum of Factorials
[Learning Goal : Simple looping]
Write a program to find the sum of factorials of positive integers from 1 to n.
Sn = 1! + 2! + 3! +��. + n!
*/

#include<stdio.h>
#include<stdlib.h>

int main()

{
	int myNum=0,i=1,sum=0,fact=1,j=1,temp=0;
		
	printf("Enter an integer value >> ");
    scanf("%d",&myNum);
    temp=myNum;
    
    while(temp)
    {
    	for(i=1;i<=temp;i++)
          {
    	   fact=fact*i;
          }
    	sum=sum+fact;
    	fact=1;
    	temp--;
	}
	
	printf("Sum of factorial of number from 1 to %d is %d\n",myNum,sum);


    system("PAUSE");
    return 0;
}

