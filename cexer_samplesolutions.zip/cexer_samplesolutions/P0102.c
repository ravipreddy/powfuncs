#include<stdio.h>
#include<stdlib.h>

int main()

{

  printf("Hello World\n");
  system("PAUSE");
  return 0;
}

