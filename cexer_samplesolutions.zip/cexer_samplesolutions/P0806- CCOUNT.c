/*
P0806 : CCOUNT.C � Character Count
[Learning Goal : Sequential Fie IO]
Write a program which will display the number of characters in a text file
*/

#include<stdio.h>
#include<stdlib.h>

int main()

{
	FILE *fptr;
	int count=0;
    char fileName[100], myChar;

    printf("Enter the filename (remo.txt) to open >> ");
    scanf("%s", fileName);
    

    fptr = fopen(fileName, "r");
    if (fptr == NULL)
    {
        printf("Cannot open file \n");
        exit(0);
    }

   
    while((myChar=fgetc(fptr))!= EOF)
	{
        
		count++;  
		//printf("%d %c\n",count,myChar);     
    } 
    
    printf("Total Character in file %s is %d \n",fileName,count);

    fclose(fptr);
    printf("\n");


    system("PAUSE");
    return 0;
}

