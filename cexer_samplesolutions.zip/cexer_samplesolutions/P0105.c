#include<stdio.h>
#include<stdlib.h>

int main()

{

  printf("Hello\nWorld\n");
  system("PAUSE");
  return 0;
}

