/*
P0403 : POWER.C � Using the Power function
[Learning Goal : using pow function]
Write a program to take in two decimal values, p and q, respectively and print the value of "p
raised to the power q" using the pow function. Does it work for negative values of q?
*/
#include<stdio.h>
#include<stdlib.h>
#include<math.h>

int main()

{
    double myNum1=0.0,myNum2=0.0,power=0.0;

    printf("Enter the first decimal value >> ");
    scanf("%lf",&myNum1);
    
    printf("Enter the second decimal value >> ");
    scanf("%lf",&myNum2);
    
    power=pow(myNum1,myNum2);
    printf("Value of %g^%g is %g \n", myNum1,myNum2,power);

  
  system("PAUSE");
  return 0;
}

