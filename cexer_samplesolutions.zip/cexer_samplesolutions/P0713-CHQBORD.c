/*
P0713 : CHQBORD.C � Chequer Board Pattern
[Learning Goal : Nested Looping]
Write a C program that will accept input of a positive integer value N and output the chequer
board pattern of that size.
Input number of rows >> 4
#.#.
.#.#
#.#.
.#.#
*/

#include<stdio.h>
#include<stdlib.h>

int main()

{
	int myNum=0,i=0,j=0,k=0;
	
	printf("Enter the positive Number >> ");
	scanf("%d",&myNum);
	
	for(i=0;i<myNum;i++)
	{
		for (j=0;j<myNum;j++)
		{
			if((i+j)%2==0)
			  printf("%c",'#');
			else
			  printf(".");
		}
		
		printf("\n");
		
	}


    system("PAUSE");
    return 0;
}

