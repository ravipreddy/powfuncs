/*
P0805 : ODDEVEN.C � Separate Odd and Even Integers
[Learning Goal : Sequential Fie IO]
Write a program that reads a text file containing integers and separates them into a file
containing odd integers (ODD.TXT) and another file containing even integers (EVEN.TXT).
The input text file can contain any number of integer values.
*/

#include<stdio.h>
#include<stdlib.h>

int main()

{
	FILE *infile, *oddfile, *evenfile;
    int myNum1=0,myNum=0,count=0,oCount=0,eCount=0;
    char myName[100];

    if((infile = fopen("number2.txt","r"))==NULL)
        {
        printf("\n  \aERROR : could not open file number2.txt");
        exit(0);
        }

    if((oddfile = fopen("odd.txt","w"))==NULL)
        {
        printf("\n  \aERROR : could not open file odd.txt");
        exit(0);
        }

    if((evenfile = fopen("even.txt","w"))==NULL)
        {
        printf("\n  \aERROR : could not open file even.txt");
        exit(0);
        }

    while(!feof(infile))
        {
        fscanf(infile,"%d",&myNum1);
        count++;
        if(!feof(infile))
            {
            //printf("  n = %d\n",n);
              if(myNum1%2) 
			  {
		        fprintf(oddfile, "%d\n",myNum1);
		         oCount++; 
			  }
              else    
			  {
				fprintf(evenfile,"%d\n",myNum1);
				eCount++;
			  }
            }
        }
    
    fclose(infile);
    fclose(oddfile);
    fclose(evenfile);
    
    printf("%d integer in file number2.txt\n",count);
    printf("%d integer stored in file odd.txt\n",oCount);
    printf("%d integer stored in file even.txt\n",eCount);
    
    
    printf("Enter the name of the file number2.txt, odd.txt or even.txt to see content >> ");
    scanf("%s",myName);
    
    infile=fopen(myName,"r");
    
    while ((fscanf(infile,"%d",&myNum)) != EOF)
	{
        
        printf ("%d\n", myNum);  
		     
    }



    system("PAUSE");
    return 0;
}

