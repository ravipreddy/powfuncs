/*
P0604 : MULT72.C � Multiples of 7
[Learning Goal : Simple looping]
Write a program to print all the positive multiples of 7 which are less than 121.
*/

#include<stdio.h>
#include<stdlib.h>

int main()

{
	int myNum=0,i=1;
    
    while(1)
    {
		myNum=7*i;
		if(myNum<121)
		 printf("%2d Multiple of 7 is %3d \n",i,myNum);
		else 
		 break;
		i++;
        
    }


    system("PAUSE");
    return 0;
}

