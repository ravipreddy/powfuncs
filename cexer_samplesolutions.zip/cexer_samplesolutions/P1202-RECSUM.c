/*
P1202 : RECSUM.C � Recursive Sum of N Integers
[Learning Goal : Writing Recursive Functions]
Write a program which contains a recursive function rec_sum with following prototype.
long int rec_sum(long int n);
Use it to compute the sum of all positive integers from 0 to n.
The function is based onthe following definition:
rec_sum(n) = 0 if n equals 0
= n + rec_sum(n-1), otherwise.
*/

#include<stdio.h>
#include<stdlib.h>

long int rec_sum(long int n);

int main()

{
	long int myNum=0L;
   
    printf("Enter positive integers : ");
    scanf("%ld", &myNum);
        
    printf("Sum = %ld\n",rec_sum(myNum));



    system("PAUSE");
    return 0;
}

long int rec_sum(long int n)
{
    if(n != 0)
        return n+rec_sum(n-1);
    else
        return n;
}


