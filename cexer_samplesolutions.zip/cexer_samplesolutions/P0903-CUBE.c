/*
P0903 : CUBE.C � Cube Function
[Learning Goal : Writing User Defined Functions]
Write a program which contains a user defined function cube with the following function
prototype.
double cube (double x);
Given any value x, it returns the cube of the value.
*/

#include<stdio.h>
#include<stdlib.h>

double cube (double x);

int main()

{
	double myNum=0.0;
	
	printf("Enter if number >> ");
	scanf("%lg",&myNum);
	
	printf("The cube of number %lg is %lg\n ",myNum,cube(myNum));


    system("PAUSE");
    return 0;
}
double cube (double x)
{
	return x*x*x;
}

