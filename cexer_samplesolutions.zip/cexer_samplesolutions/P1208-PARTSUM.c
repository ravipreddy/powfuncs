/*
P1208 : PARTSUM.C � Recursive Partial Sum
[Learning Goal : Writing Recursive Functions]
Write a recursive function to compute the n-th partial sum, Sn, of the continued fraction given
below
Define the recursive function and write a function with the following prototype,
double rec_sum(int n);
*/

#include<stdio.h>
#include<stdlib.h>
double rec_sum(long int n);


int main()

{
	long int myNum=0;

    printf("Enter N Term : ");
    scanf("%ld", &myNum);

    printf("Partial Sum = %lg\n",rec_sum(myNum));



    system("PAUSE");
    return 0;
}

double rec_sum(long int n)
{
    if(n != 0)
        return 1 + 1/rec_sum(n-1);
    else
        return 1;
}


