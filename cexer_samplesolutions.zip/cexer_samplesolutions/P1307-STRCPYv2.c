/*
P1307 : STRCPY.C � String Copy Function
[Learning Goal : Using Pointers]
Write a program that reads text from a file and prints the frequency count of words of different
length.
*/

#include<stdio.h>
#include<stdlib.h>

int main()

{
	FILE *fptr;
	int i=0,val[10]={0},length=0;
    char fileName[100], buf[100];

    printf("Enter the filename (Samp.txt) to open >> ");
    scanf("%s", fileName);
    

    fptr = fopen(fileName, "r");
    
    if (fptr == NULL)
    {
        printf("Cannot open file \n");
        exit(0);
    }
    
    printf("The content of the file are\n");
    
    while( fscanf(fptr, "%s", buf) != EOF )
        {
            printf("%s ", buf);
            while(buf[i]!='\0'&& buf[i]!='.')
             {
             	length++;
             	i++;
			 }
            if(length==1)
              val[0]=val[0]+1;
            if(length==2)
              val[1]=val[1]+1;
            if(length==3)
              val[2]=val[2]+1;
            if(length==4)
              val[3]=val[3]+1;
            if(length==5)
              val[4]=val[4]+1;
            if(length==6)
              val[5]=val[5]+1;
            if(length==7)
              val[6]=val[6]+1;
            if(length==8)
              val[7]=val[7]+1;
            if(length==9)
              val[8]=val[8]+1;
            if(length==10)
              val[9]=val[9]+1;
			
			length=0;
			i=0;    
        }
    
    
    i=0;
    for(i=0;i<10;i++)
    {
     printf("\nTotal word with %d letter is %d", i+1,val[i]);
	}
   
    fclose(fptr);
    
    printf("\n");

    system("PAUSE");
    return 0;
}

