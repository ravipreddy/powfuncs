/*
P1701 : STRUCT1.C � Using Structures
[Learning Goal : Using Structures]
Write a program containing a user defined function that computes and returns the squares of
3 integers passed to in a single function call. Define a struct with following members to store
the results and return them.
int k1;
int k2;
int k3;
*/

#include<stdio.h>
#include<stdlib.h>

typedef struct
{
	int k1;
	int k2;
	int k3;
	
}data;

data square(int,int,int);

int main()

{
	int a=0,b=0,c=0;
	data d1,d3;
	
	printf("Enter the first Value >> ");
	scanf("%d",&a);
	
	printf("Enter the Second Value >> ");
	scanf("%d",&b);
	
	printf("Enter the Third  Value >> ");
	scanf("%d",&c);
	
	d3=square(a,b,c);
	
	printf("Square of value %d is %d\n",a,d3.k1);
	printf("Square of value %d is %d\n",b,d3.k2);
	printf("Square of value %d is %d\n",c,d3.k3);
	
	system("PAUSE");
    return 0;
}

data square(int a,int b, int c)
{
	data d2;
	d2.k1=a*a;
	d2.k2=b*b;
	d2.k3=c*c;
	
	return d2;
}

