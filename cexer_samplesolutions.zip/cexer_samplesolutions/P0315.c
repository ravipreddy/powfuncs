/*
P0315 : FRACT.C � Fraction Conversion
[Learning Goal : arithmetic, io]
Given two integer values representing the numerator and the denominator of a fraction, print
the equivalent decimal value. For example, if numerator is -1 and denominator is 2, then
equivalent decimal value is -0.5.
*/

#include<stdio.h>
#include<stdlib.h>


int main()

{

  int num=0,den=0;
  double fracEq=0.0;
  
  
  printf("Enter  numerator integer value  >>");
  scanf("%d",&num);
  printf("You have entered : %d\n",num);
  
  printf("Enter  denominator integer value  >>");
  scanf("%d",&den);
  printf("You have entered : %d\n",den);
  
  fracEq=(double)num/den;
  
  
  printf("The value of %d/%d is %lg\n",num,den,fracEq);
  
      
  system("PAUSE");
  return 0;
}

