/*
P0904 : NPOW.C � Power Function
[Learning Goal : Writing User Defined Functions]
Write a program which contains a user defined function npower with the following function
prototype.
double npow (double x, int n);
Given any value x and any integer n, it returns "x raised to the power n". the power n maybe
negative or positive.
*/

#include<stdio.h>
#include<stdlib.h>
#include<math.h>
double npow (double x, int n);

int main()

{
	int power=0;
	double myNum=0.0;
	
	printf("Enter the number >>");
	scanf("%lg",&myNum);
	
	printf("Enter the power value >> ");
	scanf("%d",&power);
	
	printf("The value of %g^%d is %g\n",myNum,power,npow(myNum,power));


    system("PAUSE");
    return 0;
}
double npow (double x, int n)
{
	double ans=x;
	int i=1;
	if(n>0)
	{
	   while(i<n)
	   {
		ans=ans*x;
		i++;
	   }
	  return ans;
	}
	
	if(n<0)
	{
		n=n*-1;
		while(i<n)
		{
		  ans=ans*x	;
		  i++;
		}
		return (1/ans);
	}
	
}

