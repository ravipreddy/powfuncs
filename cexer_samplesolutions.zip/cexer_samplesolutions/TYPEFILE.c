/*
P1603 : TYPEFILE.C � Type Contents of a File
[Learning Goal : Using Command Line Arguments]
Write a program to take a filename as a command line argument and display its contents on
the monitor.
c:\ typefile mytext.txt
*/

#include<stdio.h>
#include<stdlib.h>

int main(int argc, char * argv[])

{
	FILE *fptr;
	int i=0;
    char *fileName, myChar;
    
    fileName=argv[1];
    
    printf("Content of the file %s is\n",fileName);
    
    fptr = fopen(fileName, "r");
    
    if (fptr == NULL)
    {
        printf("Cannot open file \n");
        exit(0);
    }

   
    while ((myChar=fgetc(fptr))!=EOF)
	{
        printf ("%c", myChar);        
    }

    fclose(fptr);
    printf("\n");


    system("PAUSE");
    return 0;
}

