/*
P1604 : TYPEFILE.C � Type Contents of a File
[Learning Goal : Using Command Line Arguments]
Write a program to take a filename as a command line argument and copy its contents to
another file whose name is given as the second argument.
c:\ copyfile mytext1.txt mycopy.txt
*/

#include<stdio.h>
#include<stdlib.h>

int main(int argc, char * argv[])

{
	FILE *fptr,*cptr;
	int i=0;
    char *fileName,*fileCopy, myChar;

    fileName=argv[1];
    fileCopy=argv[2];

    if(argc != 3)
    {
        printf("Usage : copyfile fromfilename tofilename\n");
        exit(0);
    }


    fptr = fopen(fileName, "r");
    cptr = fopen(fileCopy, "w");

    if (fptr == NULL)
    {
        printf("Cannot open file \n");
        exit(0);
    }

    while ((myChar = fgetc(fptr)) != EOF)
	{

        fputc((myChar),cptr);

    }

    fclose(fptr);
	fclose(cptr);

    cptr = fopen(fileCopy, "r");


	printf("Content of the file %s is\n",fileCopy);
	do
	{
        myChar = fgetc(cptr);
		printf ("%c", myChar);
    }while (myChar!=EOF);

    fclose(cptr);

    printf("\n");
	system("PAUSE");
    return 0;
}

