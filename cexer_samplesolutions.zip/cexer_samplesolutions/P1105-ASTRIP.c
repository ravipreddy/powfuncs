/*
P1105 : ASTRIP.C � Keep Letters Only
[Learning Goal : Working with Strings]
Write a program which takes in a line of text entered by the user and removes non-alphabetic
characters from the string.
*/

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int main()

{
	char myChar[100],copyText[100];
	int i=0,j=0;

	printf("Enter a line of text >> ");
	gets(myChar);

	for(i=0;myChar[i]!='\0';i++)
	{
		if(isalpha(myChar[i]))
		  {
		  	copyText[j]=myChar[i];
		  	j++;
		  }
	}
	copyText[j]=='\0';

   printf("The Modified String is [%s] \n",copyText);


    system("PAUSE");
    return 0;
}

