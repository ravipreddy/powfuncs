/*
P1108 : REVWSEQ.C � Reverse Word Sequence
[Learning Goal : Working with Strings]
Write a program which takes in a line of text entered by the user. The words are printed in the
reverse order
*/

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int main()

{
	char myChar[100],copyText[100]; 
	int length=0,i=0,j=0,count=0,k=0,word=0;
    
	
	printf("Enter a line of text >> ");
	gets(myChar);
	
	    
	length = strlen(myChar); 
	//printf("Length of String is %d\n",length);
  
    for (i=length-1; i >= 0; i--) 
	{ 
        count++;
        
		if (myChar[i] == ' '|| i==0) 
        {
           if(i==0)
		   {
		   	copyText[j]=' ';
			j++;
		   }
		   
		   while(count>0)
			{
			    copyText[j]=myChar[i+k];
				count--;
				j++;
				k++;
				
			}
			
        } 
        
        k=0;
        
    } 
  
    copyText[j]='\0';
    
    
    printf("The Modifed Sting is %s\n",copyText);
    
    system("PAUSE");
    return 0;
}

