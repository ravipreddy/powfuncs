/*
P1109 : INWORDS.C � Number to Words
[Learning Goal : Working with Strings]
Write a program which takes in a positive integer and prints it out in words.
*/

#include<stdio.h>
#include<stdlib.h>

int main()

{
	int myNum=0,i=0;
	char myChar[100];
	
	printf("Enter an integer number >> ");
	scanf("%d",&myNum);
	
	itoa(myNum, myChar,10);
	
	
	for(i=0;myChar[i]!='\0';i++)
	{
		if(myChar[i]=='0')
		 printf("Zero ");
		if(myChar[i]=='1')
		 printf("One ");
		if(myChar[i]=='2')
		 printf("Two ");
		if(myChar[i]=='3')
		 printf("Three ");
		if(myChar[i]=='4')
		 printf("Four ");
		if(myChar[i]=='5')
		 printf("Five ");
		if(myChar[i]=='6')
		 printf("Six ");
		if(myChar[i]=='7')
		 printf("Seven ");
		if(myChar[i]=='8')
		 printf("Eight ");
		if(myChar[i]=='9')
		 printf("Nine ");
	}

    printf("\n");
    system("PAUSE");
    return 0;
}

