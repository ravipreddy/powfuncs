/*
P0811 : SHOWWORDS.C � Display File Contents
[Learning Goal : Sequential Fie IO]
Write a program to take words from a file and display them one word per line as shown below. 
*/

#include<stdio.h>
#include<stdlib.h>

int main()

{
	FILE *fptr;
	char fileName[100], myChar[100];

    printf("Enter the filename (remo.txt) to open >> ");
    scanf("%s", fileName);
    

    fptr = fopen(fileName, "r");
    
    if (fptr == NULL)
    {
        printf("Cannot open file \n");
        exit(0);
    }
    
       
    while(!feof(fptr))
        {
        fscanf(fptr,"%s",myChar);        
        printf("%s\n",myChar);
        }
        
    fclose(fptr);


    system("PAUSE");
    return 0;
}

