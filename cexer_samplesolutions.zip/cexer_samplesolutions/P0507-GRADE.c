/*
P0507 : GRADE.C � Computing the Grade
[Learning Goal : Simple comparisons]
A college assigns grades for the following percentages:
(i) if marks < 35, then grade is F.
(ii) If marks >= 35 but < 50 then grade is D.
(iii) If marks >= 50 but < 65 then grade is C.
(iv) If marks >= 65 but < 80 then grade is B.
(iv) If marks > 80 then grade is A.
Write a using nested if statement to compute the grade for any given value of marks entered
as input.
*/
#include<stdio.h>
#include<stdlib.h>

int main()

{
  int marks=0;
  char grade=NULL;
	
  printf("Enter the Marks Scored >> ");
  scanf("%d",&marks);
  
  if(marks<35)
   grade='F';
  else if(marks>=35 && marks<50)
   grade='D';
  else if(marks>=50 && marks <65)
   grade='C';
  else if(marks>=65 && marks <80)
   grade='B';
  else
   grade='A';
  
  printf("The Grade for Marks %d is %c\n",marks,grade);



  system("PAUSE");
  return 0;
}

