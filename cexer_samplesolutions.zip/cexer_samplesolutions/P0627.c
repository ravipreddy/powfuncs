/*
P0627 : DIV13.C � Converting Percentage to Grades
[Learning Goal : Simple logic]
Write a program to convert a given positive integer between 0 to 100, indicating a
percentage value, into the equivalent grade using the following ranges.
>= 90% O grade
80 to 89 E grade
70 to 79 A grade
60 to 69 B grade
50 to 59 C Grade
37 to 49 D grade
< 37 F grade
*/

#include<stdio.h>
#include<stdlib.h>

int main()

{
	int myNum=0;
	
	printf("Enter an integer value >> ");
    scanf("%d",&myNum);
    
    if(myNum>=90)
      printf("Your Grade for %d marks is O\n",myNum);
    
	else if(myNum>=80 && myNum<89)
      printf("Your Grade for %d marks is E\n",myNum);
    
    else if(myNum>=70 && myNum<79)
      printf("Your Grade for %d marks is A\n",myNum);
    
    else if(myNum>=60 && myNum<69)
      printf("Your Grade for %d marks is B\n",myNum);
    
    else if(myNum>=50 && myNum<59)
      printf("Your Grade for %d marks is C\n",myNum);
      
    else if(myNum>=37 && myNum<49)
      printf("Your Grade for %d marks is D\n",myNum);
    
    else
      printf("Your Grade for %d marks is F\n",myNum);


    system("PAUSE");
    return 0;
}

