/*
P0810 : RBLANK.C � Remove Blank Lines
[Learning Goal : Sequential Fie IO]
Write a program to remove all blank lines from a given text file and store in another file.

*/

#include<stdio.h>
#include<stdlib.h>

int main()

{
	FILE *fptr,*cptr,*fptr1;
    int count=0;
    char fileName[100],fileCopy[100], myChar,myChar1;

    printf("Enter the filename (remoB.txt) to open >> ");
    scanf("%s", fileName);

    fptr = fopen(fileName, "r");
    if (fptr == NULL)
    {
        printf("Cannot open file \n");
        exit(0);
    }
    
    printf("Enter the filename to copy  >> ");
    scanf("%s", fileCopy);
    
    cptr = fopen(fileCopy, "w");
    
    fptr1=fopen(fileName, "r");
    
    myChar1=fgetc(fptr1);
    
    while ((myChar=fgetc(fptr))!=EOF)
	{
        
        myChar1=fgetc(fptr1);	
	    
		
		   if (myChar1=='\n' && myChar=='\n')
		      {
		      	count++;
		      	continue;
						
			  }
			
			fputc((myChar),cptr);		     
    }
    
    fclose(fptr);
	fclose(cptr);
	
	printf("\nTotal %d Blank line removed and copied to %s\n",count,fileCopy);
	printf("\nContent of file is:\n");
    cptr = fopen(fileCopy, "r");
	
	while ((myChar = fgetc(cptr)) != EOF)
	{
        printf ("%c", myChar);        
    } 
    
    fclose(cptr);
    printf("\n");



    system("PAUSE");
    return 0;
}

