/*
P0703 : DIGPAT2.C � Digit Pattern 2
[Learning Goal : Nested Looping]
Write a program which, given an integer n as input, generates a pyramid of n lines using the
last digit of the line number (starting from 1). The output for n=5 is shown below as an
example. 
Input size n >> 5
1
12
123
1234
12345
1234
123
12
1
*/

#include<stdio.h>
#include<stdlib.h>

int main()

{
	int myNum=0,i=0,j=0;
	
	printf("Enter an integer value >> ");
	scanf("%d",&myNum);
	
	for(i=0;i<myNum;i++)
	{
		for(j=0;j<=i;j++)
		 {
		   printf("%2d",j+1);
	     }
	    
		printf("\n"); 
	}
	
	for(i=0;i<myNum;i++)
	{
		for(j=0;j<(myNum-i-1);j++)
		 {
		   printf("%2d",j+1);
	     }
	    
		printf("\n"); 
	}


    system("PAUSE");
    return 0;
}

