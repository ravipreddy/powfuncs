/*
P0303 : ARITH2.C � Decimal Arithmetic
[Learning Goal : decimal arithmetic]
Read in two decimal values p and q entered by the user and print out the values of the
following expressions
p+q p-q p*q p/q
Run your program for the following cases:
(a) Both inputs are positive values
(b) Both inputs are negative values
(c) One is positive and the other is negative.
*/

#include<stdio.h>
#include<stdlib.h>


int main()

{

  float j=0.0,k=0.0;
  
  
  printf("Enter value for j >>");
  scanf("%f",&j);
  printf("You have entered : %f\n",j);
  
  printf("Enter value for k >>");
  scanf("%f",&k);
  printf("You have entered :%f\n",k);
  
  
  
  printf("Result of j+k is %f\n",j+k);
  printf("Result of j-k is %f\n",j-k);
  printf("Result of j*k is %f\n",j*k);
  printf("Result of j/k is %f\n",j/k);
  
  
  system("PAUSE");
  return 0;
}

