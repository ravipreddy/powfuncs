/*
P0618 : INTSQR.C � Squares of Integers
[Learning Goal : Simple logic]
Write a program to print the squares of all numbers from 1 to N where N is given by the user.
It should also print the sum of these squares.
*/

#include<stdio.h>
#include<stdlib.h>
#include<math.h>

int main()

{
	int myNum=0,sumSquare=0,square=0,i=1;

	printf("Enter an integer value >> ");
    scanf("%d",&myNum);

    while(i<=myNum)
    {
    	square = i * i;
		printf("The square of digit of %d is %d\n",i,square);
		sumSquare=sumSquare+square;
		i++;
	}

	printf("The sum of square of all numbers from 1 to %d is %d\n",myNum,sumSquare);

    system("PAUSE");
    return 0;
}

