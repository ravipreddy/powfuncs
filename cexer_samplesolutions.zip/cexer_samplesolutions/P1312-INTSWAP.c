/*
P1312 : INTSWAP.C � Integer Swapping
[Learning Goal : Using Pointers]
Write a program using a user defined function to swap two integers suing a swap function
defined as follows:
void int_swap(int *a, int *b);
*/

#include<stdio.h>
#include<stdlib.h>

void int_swap(int *a, int *b);
int main()

{
	int a=0,b=0;
	
	printf("Enter Integer 1 >> ");
	scanf("%d",&a);
	
	printf("Enter Integer 2 >> ");
	scanf("%d",&b);
	
	printf("The value of a=%d and b=%d\n",a,b);
	
	int_swap(&a,&b);
	
	printf("After Swapping the value of a=%d and b=%d\n",a,b);
	
	
    system("PAUSE");
    return 0;
}

void int_swap(int *a, int *b)
{
	int temp;
	
   temp=*b;
   *b=*a;
   *a=temp;
   
   return;
}

