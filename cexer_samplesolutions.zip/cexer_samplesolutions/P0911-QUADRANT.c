/*
P0911 : QUADRANT.C � Quadrant Check
[Learning Goal : Writing User Defined Functions]
Write a function that will take the coordinates (x,y) of a point in 2-dimensional space and return
the quadrant in which the point exists. Use the prototype
char quadrant(double x, double y);
If the point is in quadrant 1 (x>0.0 and y>0.0), return '1'.
If the point is in quadrant 2 (x<0.0 and y>0.0), return '2'.
If the point is in quadrant 3 (x<0.0 and y<0.0), return '3'.
If the point is in quadrant 4 (x>0.0 and y<0.0), return '4'.
If the point is on the X-axis, return 'X'
If the point is on the Y-axis, return 'Y'.
If the point is at the origin (0,0), return 'O'
*/

#include<stdio.h>
#include<stdlib.h>
char quadrant(double x, double y);

int main()

{
	double x=0.0,y=0.0;
	
	printf("Enter x coordinate >> ");
	scanf("%lg",&x);
	
	printf("Enter y coordinate >> ");
	scanf("%lg",&y);
	
	printf("The quandrant for x=%lg y=%lg is Quadrant: %c \n",x,y,quadrant(x,y));
	


    system("PAUSE");
    return 0;
}
char quadrant(double x, double y)
{
	if (x>0.0 && y>0.0) return '1';
	if (x<0.0 && y>0.0) return '2';
	if (x<0.0 && y<0.0) return '3';
	if (x>0.0 && y<0.0) return '4';
	if (x==0.0 && y==0.0) return 'O';
	if (x==0.0 && y!=0.0) return 'Y';
	if (x!=0.0 && y==0.0) return 'X';
	
	
}

