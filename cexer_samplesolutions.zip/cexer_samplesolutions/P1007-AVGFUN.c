/*
P1007 : AVGFUN.C � Aggregate Functions
[Learning Goal : Using One Dimensional Arrays]
Write a program which allows the user to input a certain number of decimal values and store
them in an double array. The number of values to be entered will be given by the user subject
to a maximum limit of 100 integers.
The program will print the average and standard deviation of the values given by the user by
calling a function average and another function stddev.
double average(double x, int n);
double stddev(double x, int n);

*/

#include<stdio.h>
#include<stdlib.h>
#include<math.h>

double average(double x[], int n);
double stddev(double x[], int n);

int main()

{
	int value=0,i=0;
	double myNum[100],avg=0.0,std=0.0;

	printf("How many values will you enter >>");
	scanf("%d",&value);

	if(value>100)
	{
		printf("You can only enter 100 values\n");
		system("PAUSE");
		exit(0);
	}

	for(i=0;i<value;i++)
	{
		printf("Enter value %d >> ",i+1);
		scanf("%lg",&myNum[i]);
	}

	avg=average(myNum,value);
	std=stddev(myNum,value);

	printf("The average of %d is %lg\n",value,avg);
	printf("The standard deviation is %lg\n",std);

    system("PAUSE");
    return 0;
}

double average(double x[], int n)
{
	int i=0;
	double avg=0.0,sum=0.0;
	for(i=0;i<n;i++)
	   sum=sum+x[i];
	avg=sum/n;
	return avg;
}


double stddev(double x[], int n)
{
	int i=0;
	double std=0.0, avg=0.0,sum=0.0,ssum=0.0;

	for(i=0;i<n;i++)
	   sum=sum+x[i];

	avg=sum/n;

	for(i=0;i<n;i++)
    	ssum=ssum+(x[i]- avg)*(x[i]- avg);


	std=ssum/(n-1.0);
	std=sqrt(std);

	return std;

}

