/*
P1704 : STUDENT.C � Storing student data
[Learning Goal : Using Structures]
Define a struct with following members to store student information. It will be designed to
store the following information about each student:
? Roll Number
? First Name
? Last Name
? Gender
? Date of Birth
? Class
? Section
The program should allow user to input data for 10 students and display it
*/

#include<stdio.h>
#include<stdlib.h>

typedef struct
{
	int rollnum;
	char firstName[50];
	char lastName[50];
	char gender;
	char dob[15];
	char clas[15];
	char section;
	
	
	
}student;

int main()

{
	student s[10];
	int i=0;
	
	for(i=0;i<1;i++)
	{
		printf("Enter roll number of student %d >>",i+1);
		scanf("%d",&s[i].rollnum);
		
		printf("Enter first name of student %d >>",i+1);
		scanf("%s",s[i].firstName);
		
		printf("Enter last name of student %d >>",i+1);
		scanf("%s",s[i].lastName);
		
		fflush(stdin);
		
		printf("Enter Gender of student %d >>",i+1);
		scanf("%c",&s[i].gender);
		
		printf("Enter date of birth (DD-MMM-YY) of student %d >>",i+1);
		scanf("%s",s[i].dob);
		
		printf("Enter class of student %d >>",i+1);
		scanf("%s",s[i].clas);
		
		fflush(stdin);
		
		printf("Enter Section of student %d >>",i+1);
		scanf("%c",&s[i].section);
		
		
	}
	
	for(i=0;i<1;i++)
	{
		printf("\nRoll number of student %d is %d\n",i+1,s[i].rollnum);		
		printf("First name of student %d  is %s\n",i+1,s[i].firstName);		
		printf("Last name of student %d is %s\n",i+1,s[i].lastName);		
		printf("Gender of student %d  is %c\n",i+1,s[i].gender);
		printf("DoB of student %d  is %s\n",i+1,s[i].dob);
		printf("Class of student %d  is %s\n",i+1,s[i].clas);
		printf("Section of student %d  is %c\n",i+1,s[i].section);
	}
	


    system("PAUSE");
    return 0;
}

