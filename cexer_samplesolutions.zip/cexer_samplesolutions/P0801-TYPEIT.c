/*
P0801 : TYPEIT.C � Display File Contents
[Learning Goal : Sequential Fie IO]
Write a program which will display the contents of a file on the monitor.
*/

#include<stdio.h>
#include<stdlib.h>

int main()

{
	FILE *fptr;

    char fileName[100], myChar;

    printf("Enter the filename (remo.txt) to open >> ");
    scanf("%s", fileName);
    

    fptr = fopen(fileName, "r");
    if (fptr == NULL)
    {
        printf("Cannot open file \n");
        exit(0);
    }

   
    do
	{
        myChar = fgetc(fptr);
		printf ("%c", myChar);        
    }while (myChar != EOF); 

    fclose(fptr);
    printf("\n");



    system("PAUSE");
    return 0;
}

