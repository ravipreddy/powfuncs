/*
P0812 : NUMBER.C � Display File Contents
[Learning Goal : Sequential Fie IO]
Write a program which will display the contents of a file on the monitor where each line prefixed
by a 3 digit line number and a colon.
*/

#include<stdio.h>
#include<stdlib.h>

int main()

{
	FILE *fptr;
    int count=0,counter=1;
    char fileName[100], myChar;

    printf("Enter the filename (remo.txt) to open >> ");
    scanf("%s", fileName);
    

    fptr = fopen(fileName, "r");
    if (fptr == NULL)
    {
        printf("Cannot open file \n");
        exit(0);
    }

   
    while((myChar=fgetc(fptr))!=EOF)
	{
        if(count==0)
          {
		  	printf("%03d:%c",counter,myChar);
			count++; 
	      }
		
		else if(myChar=='\n')
		{
		  counter++;
		  printf("%c%03d:",myChar,counter);	
		}
		
		else 
		  printf ("%c", myChar);  
		
		
		  //printf("001"); 
	//printf ("%c", myChar);        
    }

    fclose(fptr);
    printf("\n");


    system("PAUSE");
    return 0;
}

