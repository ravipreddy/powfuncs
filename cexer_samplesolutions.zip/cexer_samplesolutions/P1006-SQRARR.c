/*
P1006 : SQRARR.C � Squaring values of an array
[Learning Goal : Using One Dimensional Arrays]
Given an integer array, write a function to create a second array containing squares of the
corresponding integers in the first array. Use a function sqr_array with prototype given below:
void sqr_array(int n, int arr[], int sqr[]);
*/

#include<stdio.h>
#include<stdlib.h>

void sqr_array(int n, int arr[], int sqr[]);

int main()

{
	int array[]={1,-3,5,-2,9,10},items=0,array1[items],i=0;
    
    items=sizeof(array)/sizeof(int);
    
    printf("\n Original Array ") ; 	
	for(i=0;i<items;i++)
	  	printf("%d ",array[i]);
    
    sqr_array(items, array, array1);
    
    printf("\n Square of Array ") ;   	
	for(i=0;i<items;i++)
	 	printf("%d ",array1[i]);
    

    printf("\n");
    system("PAUSE");
    return 0;
}
void sqr_array(int n, int arr[], int sqr[])
{
	int i=0;
	for(i=0;i<n;i++)
	  sqr[i]=arr[i]*arr[i];
}
