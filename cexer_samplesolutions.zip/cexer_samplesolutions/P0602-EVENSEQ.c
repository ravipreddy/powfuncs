/*
P0602 : EVENSEQ.C � Even Integer Sequence
[Learning Goal : Simple looping]
Write a program to print all even integers between 1 and 100.
*/

#include<stdio.h>
#include<stdlib.h>

int main()

{
	
    int myNum=1,i=0;
    for(i=0;i<100;i++)
    {
		if(myNum%2==0)
		  printf("%d  ",myNum);
        myNum++;
    }

    system("PAUSE");
    return 0;
}

