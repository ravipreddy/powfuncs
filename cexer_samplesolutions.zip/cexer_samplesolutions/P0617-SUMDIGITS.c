/*
P0617 : SUMDIGITS.C � Sum of Digits
[Learning Goal : Simple logic]
Write a program to print the sum of the digits of a given positive integer.
*/

#include<stdio.h>
#include<stdlib.h>

int main()

{
	int myNum=0,sumDigit=0,tempNum=0,myNum1=0;
	
	printf("Enter the positive number >> ");
    scanf("%d",&myNum);
    myNum1=myNum;
    
    while(myNum!=0)
    {
      tempNum=myNum%10;
      sumDigit=sumDigit+tempNum;
      myNum=myNum/10;
	  	
	}
	
	printf("The sum of the digit of %d is %d\n",myNum1,sumDigit);


    system("PAUSE");
    return 0;
}

