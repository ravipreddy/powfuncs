/*
P0409 : MEANS.C � Computing Means
[Learning Goal : Using pow function]
Write a program to read 3 decimal values (p, q, r) and print their arithmetic, geometric and
harmonic means.
*/
#include<stdio.h>
#include<stdlib.h>
#include<math.h>
int main()

{
	double p=0.0,q=0.0,r=0.0;
	double aMean=0.0,gMean=0.0,hMean=0.0;
	
	printf("Enter the first decimal value >> ");
	scanf("%lf",&p);
	
	printf("Enter the second decimal value >> ");
	scanf("%lf",&q);
	
	printf("Enter the third decimal value >> ");
	scanf("%lf",&r);
	
	aMean=(p+q+r)/3;
	gMean=pow((p*q*r),1.0/3);
	hMean=3/(1/p+1/q+1/r);
	
	printf("The arithmetic mean of %g,%g,%g is %g\n",p,q,r,aMean);
	printf("The geometric mean of %g,%g,%g is %g\n",p,q,r,gMean);
	printf("The harmonic mean of %g,%g,%g is %g\n",p,q,r,hMean);	


  system("PAUSE");
  return 0;
}

