/*
P1401 : IARRAY.C � Integer Array Sizing
[Learning Goal : Using Dynamic Memory Allocation]
A text file contains a certain number of integers with the number of integers in the first line and
the integer data starts in second line as shown in the sample below.
10
100 345 667 -9 -8 -23 -778 374 322 287
Write a program to read the data from such files into an integer array that is dynamically sized.

*/

#include<stdio.h>
#include<stdlib.h>

int main()

{
	FILE *fptr;
	int value=0,i=0,val[10]={0},length=0,*iptr;
    char fileName[100], buf[100];

    printf("Enter the filename (file.txt) to open >> ");
    scanf("%s", fileName);
    

    fptr = fopen(fileName, "r");
    
    if (fptr == NULL)
    {
        printf("Cannot open file \n");
        exit(0);
    }
    
    fscanf(fptr, "%d", &value) ;
    printf("Total Value in File >>%d\n",value);
    
    iptr=(int*)calloc(value,sizeof(int));
    
	for(i=0i;i<value;i++)
    {
    	
    	fscanf(fptr, "%d", (iptr+i) );
    }
    
    for(i=0i;i<value;i++)
    {
    	
    	
    	printf("%d %d \n",i+1,*(iptr+i));
	}
    

    fclose(fptr);
    free(iptr);
	printf("\n");
	system("PAUSE");
    return 0;
}

