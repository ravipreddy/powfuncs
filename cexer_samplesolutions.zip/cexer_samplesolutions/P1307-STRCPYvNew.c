#include<stdio.h>
#include<stdlib.h>
#include<ctype.h>

int main()

{
	FILE *fptr,*fptr1;
	int count=0,sCount=0;
	int i=0,one=0,two=0, three=0,four=0,five=0,six=0,seven=0,length=0;
    char fileName[100],  myChar,myChar1;

    printf("Enter the filename (samp.txt) to open >> ");
    scanf("%s", fileName);
    

    fptr = fopen(fileName, "r");
    fptr1=fopen(fileName, "r");
    if (fptr == NULL)
    {
        printf("Cannot open file \n");
        exit(0);
    }

    myChar1=fgetc(fptr1);
    
    while((myChar=fgetc(fptr))!= EOF)
	{
        if(myChar!=' '&& myChar1!='.')
		  length++;
        //printf("Outside-%d\n",length);
		myChar1=fgetc(fptr1);
              
		if(isgraph(myChar) && !isgraph(myChar1) )
		{
		  //printf("[%c] [%c]",myChar,myChar1); 
		  sCount++;
		  
		  //printf("         Inside %d\n",length);
		  
		  if(length==1)
              one++;
          if(length==2)
              two++;
          if(length==3)
              three++;
          if(length==4)
              four++;
          if(length==5)
              five++;
          if(length==6)
              six++;
          if(length==7)
              seven++;
		   
		   
		   length=0;
		   
		  
	    }

    } 
    
    printf("\nTotal word in file %s is %d \n",fileName,sCount);
   
    printf("\n\nTotal word with 1 letter is %d\n",one);
    printf("Total word with 2 letter is %d\n",two);
    printf("Total word with 3 letter is %d\n",three);
    printf("Total word with 4 letter is %d\n",four);
    printf("Total word with 5 letter is %d\n",five);
    printf("Total word with 6 letter is %d\n",six);
    printf("Total word with 7 letter is %d\n",seven);

    fclose(fptr);
    printf("\n");



    system("PAUSE");
    return 0;
}

