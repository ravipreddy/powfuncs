/*
P1204 : REVSTR.C � Recursive String Reversal
[Learning Goal : Writing Recursive Functions]
Write a program which contains the following function to recursively reverse a string.
void revstring(void)
{
char c;
 c=getchar();
 if(c != '\n')
 revstring();
 putchar(c);
 return;
}
*/

#include<stdio.h>
#include<stdlib.h>
void revstring(void);

int main()

{
	printf("Enter the String >> ");
    revstring();
    printf("\n");



    system("PAUSE");
    return 0;
}

void revstring(void)
{
    char c;
    c=getchar();
    if(c != '\n')
        revstring();
    putchar(c);
    return;
}


