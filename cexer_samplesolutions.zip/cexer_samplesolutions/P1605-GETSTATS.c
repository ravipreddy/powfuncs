/*
P1605 : GETSTATS.C � Analyse Integer Data
[Learning Goal : Using Command Line Arguments]
Write a program to take a filename as a command line argument. The file contains an
undefined number of integer values. Your program should compute and display the number
of values, minimum value, maximum value and the average value.
c:\ getstats myvals.txt
Number of values = 204
Minimum = 17
Maximum = 789
Average = 234.567
*/

#include<stdio.h>
#include<stdlib.h>

int main(int argc, char * argv[])
{
	FILE *fptr;
	int i=0,count=0,myNum=0,sum=0,max=0,min=0;
	double average=0.0;
    char *fileName, myChar;
    
    fileName=argv[1];
    
    //printf("Content of the file %s is\n",fileName);
    
    fptr = fopen(fileName, "r");
    
    while(!feof(fptr))
        {
        fscanf(fptr,"%d",&myNum);
        count++;
        
		if(myNum<=min || count==1)
		   min=myNum; 
		
		if(myNum>=max)
           max=myNum;
          
        sum=sum+myNum;
        }
    average=(double)sum/count;
    
	printf("Total Values in file [%s] is %d\n",fileName,count);
	printf("Max of Values in file [%s] is %d\n",fileName,max); 
	printf("Min of Values in file [%s] is %d\n",fileName,min);  
	printf("Sum of Values in file [%s] is %d\n",fileName,sum);  
	printf("Avg of Values in file [%s] is %lg\n",fileName,average);     


    system("PAUSE");
    return 0;
}

