/*
P0901 : RECIPROC.C � Reciprocal Function
[Learning Goal : Writing User Defined Functions]
Write a program which contains a user defined function reciproc (which computes 1/x given
any x) with the following function prototype.
double reciproc (double x);
*/

#include<stdio.h>
#include<stdlib.h>
double reciproc (double x);
int main()

{
	double myNum=0.0;
	
	printf("Enter a number >> ");
	scanf("%lf",&myNum);
	printf("You have entered %lg\n",myNum);
	
	printf("The reiprocal of x= %lg is (1/x)=%lg\n",myNum,reciproc(myNum));


    system("PAUSE");
    return 0;
}
double reciproc (double x)
{
	return 1/x;
	
}

