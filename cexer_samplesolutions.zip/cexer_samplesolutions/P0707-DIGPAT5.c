/*
P0707 : DIGPAT5.C � Digit Pattern 5
[Learning Goal : Nested Looping]
Write a C program to generate and print the pyramid of numbers for any given integer n.
The output for n=5 is shown below.
Input size n >> 5
     1
    2 2
  3 3 3
 4 4 4 4
5 5 5 5 5
*/

#include<stdio.h>
#include<stdlib.h>

int main()

{
	int myNum=0,i=0,j=0,k=0;
	
	printf("Enter the positive Number >> ");
	scanf("%d",&myNum);
	
	for(i=0;i<myNum;i++)
	{
		for (j=0;j<myNum-i-1;j++)
		{
			printf("%c",' ');
		}
		
		for(k=0;k<i+1;k++)
		  {
		  	printf("%d",i+1);
		  	printf(" ");
          }
		printf("\n");
	}



    system("PAUSE");
    return 0;
}

