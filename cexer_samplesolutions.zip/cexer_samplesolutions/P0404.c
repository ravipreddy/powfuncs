/*
P0404 : LOG10.C � Logarithms to Base 10
[Learning Goal : using the log10 function]
Write a program to read a positive decimal value and print its logarithm to base 10.
*/
#include<stdio.h>
#include<stdlib.h>
#include<math.h>

int main()

{

  double myNum=0.0, logValue=0.0;

  printf("Enter a positive value >> ");
  scanf("%lf", &myNum);

  logValue = log10(myNum);
  printf("Logarithm of %g with base 10 is : %g\n", myNum, logValue);

  system("PAUSE");
  return 0;
}

