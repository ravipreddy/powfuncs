/*
P0630 : GUESS.C � Guessing the Number
[Learning Goal : Simple logic]
The user thinks of a number between 1 and 100. Write a program to guess the user�s
number. For each guess, the user will input �low� if your guess is lower than the user
number, �high� if it is higher than his number and �correct� if the guess if correct.
What will be the best strategy to guess the value?

*/

#include<stdio.h>
#include<stdlib.h>

int main()

{
	int guess=0,upper=100,lower=1,ntries=0;
	int choice=0;

	printf("Guess a number between 1 to 100\n");
	system("PAUSE");

	guess=50;
        while(1)
        {
        printf("Enter 1 if my guess is low\n");
        printf("Enter 2 if my guess is high\n");
        printf("Enter 3 if its correct\n");
        printf("My Guess Value is %d\n Is it low, high or correct\n",guess);

        scanf("%d",&choice);

        if(choice==1)
        {
            lower = guess;
            guess = (guess+upper)/2;
            ntries++;
        }


        if(choice==2)
        {
            upper = guess;
            guess = (guess+lower)/2;
            ntries++;
        }

        if(choice==3)
            break;

        if(choice>3 || choice <1)
            printf("Incorrect choice\a\a\n");
        }
    printf("I guessed your number in %d attempts\a\a\a",ntries);
    return 0;
}

