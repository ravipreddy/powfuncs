/*
P0309 : SQUARE.C � Square Geometry
[Learning Goal : arithmetic, io]
Given the length of the side of square entered by the user, compute and display the
perimeter and area of the square.
*/

#include<stdio.h>
#include<stdlib.h>


int main()

{

  float len=0.0,area=0.0, perimeter=0.0;
  
  
  printf("Enter  value for side of Square >>");
  scanf("%f",&len);
  printf("You have entered : %g\n",len);
  
  area=len*len;
  perimeter=4*len;
  
  printf("The perimeter of the square of Side %g is %g\n",len,perimeter);
  printf("The area of the square of Side %g is %g\n",len,area);
  
      
  system("PAUSE");
  return 0;
}

