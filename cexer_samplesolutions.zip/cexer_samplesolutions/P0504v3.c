/*
P0504 : MIN2.C � Two largest integers
[Learning Goal : Simple comparisons]
Write a program to accept four integers entered by the user. Print out the largest and the
next largest numbers from the four inputs.
*/

#include<stdio.h>
#include<stdlib.h>

int main()

{
	int myNum1=0,myNum2=0,myNum3=0,myNum4=0;
	int largest=0,nLargest=0;
    
    printf("Enter first integer number >> ");
    scanf("%d",&myNum1);
    
    printf("Enter second integer number >> ");
    scanf("%d",&myNum2);
    
    printf("Enter third integer number >> ");
    scanf("%d",&myNum3);
    
    printf("Enter fourth integer number >> ");
    scanf("%d",&myNum4);
    
    if(myNum1>=myNum2 && myNum1>=myNum3 && myNum1>=myNum4)
       {
       	largest=myNum1;
		   if(myNum2>=myNum3 && myNum2>=myNum4)
		   	nLargest=myNum2;
		   	
		   else if (myNum3>=myNum2 && myNum3>=myNum4)
		    nLargest=myNum3;
		   else
		    nLargest=myNum4;
		} 
	
	if(myNum2>=myNum1 && myNum2>=myNum3 && myNum2>=myNum4)
       {
       	largest=myNum2;
		   if(myNum1>=myNum3 && myNum1>=myNum4)
		   	nLargest=myNum1;
		   	
		   else if (myNum3>=myNum1 && myNum3>=myNum4)
		    nLargest=myNum3;
		   else
		    nLargest=myNum4;
		} 
	
	if(myNum3>=myNum1 && myNum3>=myNum2 && myNum3>=myNum4)
       {
       	largest=myNum3;
		   if(myNum2>=myNum1 && myNum2>=myNum4)
		   	nLargest=myNum2;
		   	
		   else if (myNum1>=myNum2 && myNum1>=myNum4)
		    nLargest=myNum1;
		   else
		    nLargest=myNum4;
		} 
	
	if(myNum4>=myNum1 && myNum4>=myNum2 && myNum4>=myNum3)
       {
       	largest=myNum4;
		   if(myNum2>=myNum1 && myNum2>=myNum3)
		   	nLargest=myNum2;
		   	
		   else if (myNum3>=myNum1 && myNum3>=myNum2)
		    nLargest=myNum3;
		   else
		    nLargest=myNum1;
		} 

    
printf("Out of %d,%d,%d and %d the largest number is %d and next largest is %d\n",myNum1,myNum2,myNum3,myNum4, largest,nLargest   );

  system("PAUSE");
  return 0;
}

