/*
P1604 : TYPEFILE.C � Type Contents of a File
[Learning Goal : Using Command Line Arguments]
Write a program to take a filename as a command line argument and copy its contents to
another file whose name is given as the second argument.
c:\ copyfile mytext1.txt mycopy.txt
*/

#include<stdio.h>
#include<stdlib.h>

int main(int argc, char * argv[])

{
	FILE *fptr,*cptr;
	int i=0;
    char *fileName, myChar;

    fileName=argv[1];

    if(argc != 2)
    {
        printf("Usage : typefile filename\n");
        exit(0);
    }

    fptr = fopen(fileName, "r");

    if (fptr == NULL)
    {
        printf("Cannot open file \n");
        exit(0);
    }

    while ((myChar = fgetc(fptr)) != EOF)
	 putchar(myChar);

    fclose(fptr);

    return 0;
}

