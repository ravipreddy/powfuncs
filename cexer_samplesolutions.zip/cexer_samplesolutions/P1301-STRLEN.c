/*
P1301 : STRLEN.C � String Length Function
[Learning Goal : Using Pointers]
Write a program using a user defined function for finding the string length of a string passed
to it.
int my_strlen(char * s);

*/

#include<stdio.h>
#include<stdlib.h>
int my_strlen(char * s);

int main()

{
	char myChar[100];
	
	printf("Enter the String >> ");
	gets(myChar);
	
	printf("The length of the string %s is %d\n",myChar,my_strlen(myChar));


    system("PAUSE");
    return 0;
}

int my_strlen(char * s)
{
	int count=0,i=0;
	while(s[i]!='\0')
	{
		count++;
		i++;
	}
	
	
	return count;
	
}

