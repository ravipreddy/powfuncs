/*
P0808 : SQUARE.C � Squares of Numbers
[Learning Goal : Sequential Fie IO]
Write a program which will take input integers from one file named input.txt, find out the
square of each integer and write it down in a separate file named output.txt. 
*/

#include<stdio.h>
#include<stdlib.h>

int main()

{
	FILE *fptr,*cptr;
	int count=0,myNum=0;
    char fileName[100], myChar1[100];

    printf("Enter the filename (input.txt) to open >> ");
    scanf("%s", fileName);
    

    fptr = fopen(fileName, "r");
    cptr = fopen("output.txt","w");
    if (fptr == NULL)
    {
        printf("Cannot open file \n");
        exit(0);
    }
    
    if (cptr == NULL)
    {
        printf("Cannot open file \n");
        exit(0);
    }
    
    while(!feof(fptr))
        {
        fscanf(fptr,"%d",&myNum);
        
        if(!feof(fptr))
            {
              fprintf(cptr, "%d\n",myNum*myNum);
		        
            }
        }
    printf("Your output is stored in output.txt file\n");
    fclose(fptr);
    fclose(cptr);

    system("PAUSE");
    return 0;
}

