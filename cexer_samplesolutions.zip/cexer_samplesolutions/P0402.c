/*P0402 : HYPOT.C � Hypotenuse of a Right Triangle
[Learning Goal : using sqrt function]
Write a program which will take the two sides of a right triangle as input and print the length
of the hypotenuse.*/

#include<stdio.h>
#include<stdlib.h>
#include<math.h>


int main()

{
    int adjacent=0,opposite=0;
	double hypotenuse=0.0;

    printf("Enter value for adjacent side of the triangle >> ");
    scanf("%d",&adjacent);
    
    printf("Enter value for opposite side of the triangle >> ");
    scanf("%d",&opposite);
    
    hypotenuse=sqrt(adjacent*adjacent+opposite*opposite);
    printf("Hypotenuse of a right angle traingle having side %d and %d is %g\n", adjacent,opposite,hypotenuse);


  system("PAUSE");
  return 0;
}

