/*
P0607 : ISPRIME.C � Checking for Primality
[Learning Goal : Simple looping]
Write a program to check whether a given positive integer is a prime or not.
*/

#include<stdio.h>
#include<stdlib.h>

int main()

{
    int myNum=0,isPrime=0,i=0;
    
	printf("Enter a positive integer >> ");
    scanf("%d",&myNum);
    
    for(i=2;i<=myNum/2;i++)
    {
    	if(myNum%i==0)
    	  isPrime=1;
	}
    
    if(isPrime==0 && myNum!=1)
       printf("The Number %d IS a Prime Number\n",myNum);
    else
	   printf("The Number %d IS NOT a Prime Number\n",myNum);   

    system("PAUSE");
    return 0;
}

