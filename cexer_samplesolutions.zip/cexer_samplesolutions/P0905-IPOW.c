/*
P0905 : IPOW.C � Integer Power Function
[Learning Goal : Writing User Defined Functions]
Write a program which contains a user defined function npower with the following function
prototype.
long ipow (long x, int n);
Given any value x and any positive integer n, it returns "x raised to the power n".
*/

#include<stdio.h>
#include<stdlib.h>

long ipow (long x, int n);

int main()

{
	int power=0;
	long myNum=0;
	
	printf("Enter the number >>");
	scanf("%ld",&myNum);
	
	printf("Enter the power value >> ");
	scanf("%d",&power);
	
	printf("The value of %ld^%d is %ld\n",myNum,power,ipow(myNum,power));



    system("PAUSE");
    return 0;
}
long ipow (long x, int n)
{
	long ans=x;
	int i=1;
	if(n>0)
	{
	   while(i<n)
	   {
		ans=ans*x;
		i++;
	   }
	  return ans;
	}
	
	if(n<0)
	{
		n=n*-1;
		while(i<n)
		{
		  ans=ans*x	;
		  i++;
		}
		return (1/ans);
	}
	
}

