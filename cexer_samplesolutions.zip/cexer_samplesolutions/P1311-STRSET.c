/*
P1311 : STRSET.C � Character Filling
[Learning Goal : Using Pointers]
Write a program using a user defined function to set all characters in a string to a specified
character. If the original string is �India� and the given character is �$�, the modified string
will be �$$$$$�.
char * my_strset(char * str, int ch);

*/

#include<stdio.h>
#include<stdlib.h>

char*  my_strset(char * str, int ch);

int main()

{
	char myChar[100],ctr;
	
	printf("Enter the String Only >> ");
	gets(myChar);
	
	printf("The Entered string is %s \n",myChar);
	
	printf("Enter  Character >> ");
    scanf("%c",&ctr);

    printf("String after After Replacing with [%c] is [%s]\n",ctr,my_strset(myChar,ctr));



    system("PAUSE");
    return 0;
}

char*  my_strset(char * str, int ch)
{
	int i=0,k=0;
    for(i=0; str[i]!='\0' ; i++)
        if( str[i]!=' ' && str[i]!='\t' )
            str[i]=ch;
    
	return str;        

}

