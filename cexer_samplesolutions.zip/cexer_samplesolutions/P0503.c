/*
P0503 : MIN2.C � Print median integer
[Learning Goal : Simple comparisons]
Write a program to accept three integers entered by the user and print out the median of the
three numbers. (Median refers to the middle number � not the largest and not the smallest)

*/
#include<stdio.h>
#include<stdlib.h>

int main()

{
	int myNum1=0,myNum2=0,myNum3=0;
	int large=0,smallest=0,median=0;
    
    printf("Enter first integer number >> ");
    scanf("%d",&myNum1);
    
    printf("Enter second integer number >> ");
    scanf("%d",&myNum2);
    
    printf("Enter third integer number >> ");
    scanf("%d",&myNum3);
    
    if(myNum1>=myNum2 && myNum1>=myNum3)
       {
       	large=myNum1;
		   if(myNum2>myNum3)
		   {
		   	smallest=myNum3;
		   	median=myNum2;
		   }
		   else
		   {
		   	smallest=myNum2;
		   	median=myNum3;
		   }
		} 
	
	if(myNum2>=myNum1 && myNum2>=myNum3)
	 	{
	 	 large=myNum2;
		    if(myNum1>myNum3)
			{
			 smallest=myNum3;
		   	 median=myNum1;
			}
			else
		    {
		   	 smallest=myNum1;
		   	 median=myNum3;
		    }	
		}
	if(myNum3>=myNum1 && myNum3>=myNum2)
	 	{
	 	 large=myNum3;
		    if(myNum1>myNum2)
			{
			 smallest=myNum2;
		   	 median=myNum1;
			}
			else
		    {
		   	smallest=myNum1;
		   	median=myNum2;
		    }	
		}
        
    
    
printf("Out of %d, %d and %d the median number is %d\n",myNum1,myNum2,myNum3,median);


  system("PAUSE");
  return 0;
}

