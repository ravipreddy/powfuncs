/*
P0629 : DIV13.C � Printing Leap Years
[Learning Goal : Simple logic]
Write a program to print the leap years which come between any two given years input by
the user.
*/

#include<stdio.h>
#include<stdlib.h>

int main()

{
	int year1=0,year2=0,i=0, temp=0;
	
	printf("Enter the year1 in format YYYY >> ");
    scanf("%d",&year1);
    
    printf("Enter the year2 in format YYYY >> ");
    scanf("%d",&year2);
    
    if(year1>year2)
     {
     	temp=year1;
     	year1=year2;
     	year2=temp;
	 }
	 
	 	 
	 for(i=year1;i<=year2;i++)
	  {
	  	if(year1%100!=0)
		  {
		  	if(year1%4==0)
		  	 printf("The year %4d is Leap Year\n",year1);
		  }
		else if(year1%400==0)
		  printf("The year %4d is Leap Year\n",year1);
		year1++;
	  }


    system("PAUSE");
    return 0;
}

