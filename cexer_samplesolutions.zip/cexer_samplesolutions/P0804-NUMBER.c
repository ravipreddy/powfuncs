/*
P0804 : NUMBER.C � Store Integers in a File
[Learning Goal : Sequential Fie IO]
Write a program which store the positive integers input by the user into a file named
NUMBERS.TXT. A negative integer terminates the inputs from the user.

*/

#include<stdio.h>
#include<stdlib.h>
#include<ctype.h>

int main()

{
	FILE *fptr;
	int count=0,myChar=0;
    char fileName[100], myChar1[100];

    printf("Enter the filename (number.txt) to open >> ");
    scanf("%s", fileName);
    

    fptr = fopen(fileName, "w");
    if (fptr == NULL)
    {
        printf("Cannot open file \n");
        exit(0);
    }

   
    do
	{
        printf("Input a positive Integer >> ");
		scanf("%d",&myChar);
		 if(myChar>0)
		 {
		 	putw(myChar,fptr);
		 	count++;
		 }
		 else
		 printf("\nEnd of Input by User\n");
		  
		    
    }while(myChar>=0);

    fclose(fptr); 
	
	printf("%d integer input by user stored in file %s\n",count,fileName);
	   
    fptr = fopen(fileName, "r");
    
	printf("\nContent of the file %s\n",fileName);
    
	do
	{
        myChar = getw(fptr);
         if(myChar>0)
		   printf ("%d ", myChar);        
    }while(myChar!=EOF); 
    
    
    fclose(fptr); 
	printf("\n");


    system("PAUSE");
    return 0;
}

