/*
P1110 : CURRAMT.C � Currency to Words
[Learning Goal : Working with Strings]
Write a program which takes in a decimal number indicating a currency amount and prints it
out in words as required in financial documents.

*/

#include<stdlib.h>
#include<stdio.h>
#include<math.h>

int main()
{

 int div, n1;
 int flag, digit, pos, tot_dig;
 double myNum=0.0,temp=0.0;
 unsigned long rPart=0,pPart=0;

	printf("Enter a decimal value of Currency >> ");
	scanf("%lf",&myNum);

	printf("Amount Entered >> %0.2lf\n",myNum);

	rPart=(int)(myNum);
	pPart=100.0*(myNum-rPart)+0.5;
    printf("\nRupees %lu and Paise %lu\n",rPart,pPart);

 if(rPart == 0)
 {
 	printf("Zero ");
 	//exit(0);
 }

 if(rPart >= 9999999)
 	{
 		printf("please enter a number between 0 and 10000000\n\n");
 		system("Pause");
		exit(0);
 	}
 if(pPart >= 99)
 	{
 		printf("Please enter a number between 0 and 99 in paisa\n\n");
 		system("Pause");
		exit(0);
 	}
 tot_dig = 0;
 div = 1;
 n1 = rPart;

 while ( n1 > 9 )
 {
 	n1 = n1 / 10;
 	div = div * 10;

 	tot_dig++;
 }


 tot_dig++;
 pos = tot_dig;


 printf("Rupees ");

 while ( rPart != 0 )
 {

	digit = rPart / div;
 	rPart = rPart % div;
 	div = div / 10;
 	switch(pos)
	 {

 		case 2:
 		case 5:
 		case 7:


 		if ( digit == 1 )
			flag = 1;
 		else
		 {
 			flag = 0;
 			switch(digit)
		 	  {
 				case 2: printf("Twenty ");break;
 				case 3: printf("Thirty ");break;
 				case 4: printf("Forty ");break;
 				case 5: printf("Fifty ");break;
 				case 6: printf("Sixty ");break;
 				case 7: printf("Seventy ");break;
				case 8: printf("Eighty ");break;
 				case 9: printf("Ninty ");
 			  }
 		 }
 		break;


 		case 1:
 		case 4:
 		case 6:

 		if (flag == 1)
		 {
 			flag = 0;
 			switch(digit)
			 {
 				case 0 : printf("Ten ");break;
 				case 1 : printf("Eleven ");break;
				case 2 : printf("Twelve ");break;
				case 3 : printf("Thirteen ");break;
 				case 4 : printf("Fourteen ");break;
 				case 5 : printf("Fifteen ");break;
 				case 6 : printf("Sixteen ");break;
 				case 7 : printf("Seventeen ");break;
 				case 8 : printf("Eighteen ");break;
 				case 9 : printf("Nineteen ");
 			}
 		 }
		else
			{
 			 switch(digit)
			  {
 				case 1 : printf("One ");break;
 				case 2 : printf("Two ");break;
 				case 3 : printf("Three ");break;
 				case 4 : printf("Four ");break;
 				case 5 : printf("Five ");break;
 				case 6 : printf("Six ");break;
 				case 7 : printf("Seven ");break;
 				case 8 : printf("Eight ");break;
 				case 9 : printf("Nine ");
 			  }
 			}
    //1printf("[pos-%d -- dig-%d]",pos,digit);
 	if (pos == 4 && digit !=0)
 	printf("Thousand ");
 	if (pos==6)
 	printf("Lakh ");
 	break;

 	case 3:
 		if (digit > 0)
		 {
 			switch(digit)
			 {
 				case 1 : printf("One ");break;
 				case 2 : printf("Two ");break;
 				case 3 : printf("Three ");break;
 				case 4 : printf("Four ");break;
 				case 5 : printf("Five ");break;
 				case 6 : printf("Six ");break;
 				case 7 : printf("Seven ");break;
 				case 8 : printf("Eight ");break;
 				case 9 : printf("Nine ");
 			 }

			 printf("Hundred ");
 		}
 		break;
 	}

 pos--;
 }//End of while Loop


 if (pos == 4 && flag == 0)
 	printf("Thousand");
 else if (pos == 4 && flag == 1)
 	printf("Ten Thousand");

 if (pos == 1 && flag == 1)
 	printf("Ten ");



//// Start of Paisa



 if(pPart == 0)
 {
 	printf(" and zero paisa only");
 	exit(0);
 }


 tot_dig = 0;
 div = 1;
 n1 = pPart;

 while ( n1 > 9 )
 {
 	n1 = n1 / 10;
 	div = div * 10;

 	tot_dig++;
 }


 tot_dig++;
 pos = tot_dig;

 //printf(" Digit pos-%d --",pos);

 printf("and Paisa ");
//printf("Flag  %d ",flag);

 while ( pPart != 0 )
 {

	digit = pPart / div;
 	pPart = pPart % div;
 	div = div / 10;

 	//printf(" Digit-%d  pos-%d --",digit,pos);
 	switch(pos)
	 {
 		case 2:

 		if ( digit == 1 && flag==0)
 		  {
 		  	flag = 1;


		   }

 		else
		 {
 			flag = 0;

 		switch(digit)
		 	{
		 	case 1 : printf("Ten ");break;
 			case 2: printf("Twenty ");break;
 			case 3: printf("Thirty ");break;
 			case 4: printf("Forty ");break;
 			case 5: printf("Fifty ");break;
 			case 6: printf("Sixty ");break;
 			case 7: printf("Seventy ");break;
			case 8: printf("Eighty ");break;
 			case 9: printf("Ninty ");
 			}
 		}
 		break;

		 case 1:

 		if (flag == 1)
		 {
 			flag = 0;
 			switch(digit)
			 {
 				case 0 : printf("Ten ");break;
 				case 1 : printf("Eleven ");break;
				case 2 : printf("Twelve ");break;
				case 3 : printf("Thirteen ");break;
 				case 4 : printf("Fourteen ");break;
 				case 5 : printf("Fifteen ");break;
 				case 6 : printf("Sixteen ");break;
 				case 7 : printf("Seventeen ");break;
 				case 8 : printf("Eighteen ");break;
 				case 9 : printf("Nineteen ");
 			}
 		 }
		else
			{
 			 switch(digit)
			  {
 				case 1 : printf("One ");break;
 				case 2 : printf("Two ");break;
 				case 3 : printf("Three ");break;
 				case 4 : printf("Four ");break;
 				case 5 : printf("Five ");break;
 				case 6 : printf("Six ");break;
 				case 7 : printf("Seven ");break;
 				case 8 : printf("Eight ");break;
 				case 9 : printf("Nine ");
 			  }
 			}


 		break;


 	}
 pos--;
 }

if (pos == 1 && flag == 1)
 	printf("Ten ");

printf("only \n");
system("PAUSE");
return 0;
}
