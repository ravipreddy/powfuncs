/*
P1203 : UNKNOWN.C � Recursive Function
[Learning Goal : Writing Recursive Functions]
Write a program which contains the following function. Run it for a few positive values and
guess its function.
*/

#include<stdio.h>
#include<stdlib.h>
void unknown(int n);

int main()

{
	int myNum=0;
   
        printf("Enter positive integers : ");
        scanf("%d", &myNum);
       
    printf("\nThis fuction Return the  Value >>  ");
	unknown(myNum);
	printf("\n");
    



    system("PAUSE");
    return 0;
}
void unknown(int n)
{
	int digit;
	if(n)
		{
		digit = n%10;
		unknown(n/10);
		printf("%1d",digit);
		}
}

