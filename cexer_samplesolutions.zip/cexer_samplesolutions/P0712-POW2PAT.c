/*
P0712 : POW2PAT.C � Powers of 2
[Learning Goal : Nested Looping]
Write a C program that will accept input of a positive integer value N and output the pattern
based on powers of 2.
Input number of rows >> 8
          1
        1 2 1
     1 2 4 2 1
    1 2 4 8 4 2 1
   1 2 4 8 16 8 4 2 1
  1 2 4 8 16 32 16 8 4 2 1
 1 2 4 8 16 32 64 32 16 8 4 2 1
1 2 4 8 16 32 64 128 64 32 16 8 4 2 1
*/

#include<stdio.h>
#include<stdlib.h>
#include<math.h>

int main()

{
	int myNum=0,i=0,j=0,k=0;
	
	printf("Enter the positive Number >> ");
	scanf("%d",&myNum);
	
	for(i=0;i<myNum;i++)
	{
		for (j=0;j<myNum-i-1;j++)
		{
			printf("%4c",' ');
		}
		
		for(k=0;k<(i*2)+1;k++)
		  {
		  	
			  if(k==0 || k==(i*2))
                printf("%4d", 1);
              else if (k<=i)
                {
				printf("%4g",pow(2.0,k));
				//printf("[%d %d %d]",i,j,k);
				}
			   else
			   {
			   	printf("%4g",pow(2,(2*i-k)));
			   }	

		  }
		printf("\n");
	}




    system("PAUSE");
    return 0;
}

