/*
P0613 : MULTABL.C � Multiplication Table
[Learning Goal : Simple looping]
Write a program to print the multiplication table for a given positive integer. The output for
N=11 is shown below.
11 x 1 = 11
11 x 2 = 22
11 x 3 = 33
11 x 4 = 44
11 x 5 = 55
11 x 6 = 66
11 x 7 = 77
11 x 8 = 88
11 x 9 = 99
11 x 10 = 110

*/

#include<stdio.h>
#include<stdlib.h>

int main()

{
	int myNum=0,i=0;
	
	printf("Enter the positive number >> ");
	scanf("%d",&myNum);
	
	for(i=1;i<=10;i++)
	{
		printf( "%d X %2d = %d\n",myNum,i,myNum*i);
	}

    system("PAUSE");
    return 0;
}

