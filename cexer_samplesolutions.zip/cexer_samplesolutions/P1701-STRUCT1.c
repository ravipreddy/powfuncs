/*
P1701 : STRUCT1.C � Using Structures
[Learning Goal : Using Structures]
Write a program containing a user defined function that computes and returns the squares of
3 integers passed to in a single function call. Define a struct with following members to store
the results and return them.
int k1;
int k2;
int k3;
*/

#include<stdio.h>
#include<stdlib.h>

typedef struct
{
	int k1;
	int k2;
	int k3;
	
}data;

data square(data d2);

int main()

{
	data d1,d3;
	
	printf("Enter the first Value >> ");
	scanf("%d",&d1.k1);
	
	printf("Enter the Second Value >> ");
	scanf("%d",&d1.k2);
	
	printf("Enter the Third  Value >> ");
	scanf("%d",&d1.k3);
	
	d3=square(d1);
	
	printf("Square of value %d is %d\n",d1.k1,d3.k1);
	printf("Square of value %d is %d\n",d1.k2,d3.k2);
	printf("Square of value %d is %d\n",d1.k3,d3.k3);
	
	


    system("PAUSE");
    return 0;
}

data square(data d2)
{
	d2.k1=d2.k1*d2.k1;
	d2.k2=d2.k2*d2.k2;
	d2.k3=d2.k3*d2.k3;
	
	return d2;
}

