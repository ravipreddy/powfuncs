/*
P0626 : DIV13.C � Sum of Odd Positive Integers
[Learning Goal : Simple looping]
Write a program to print the first 100 odd positive integers which are not divisible by 5.

*/

#include<stdio.h>
#include<stdlib.h>

int main()

{
	int myNum=0,count=0,i=1;
	
	while(count!=100)
	{
		if(i%2!=0 && i%5!=0)
		{
			printf("%d ",i);
			count++;
		}
		i++;		
	
	}

    system("PAUSE");
    return 0;
}

