/*
P1702 : RATIONAL.C � Rational Numbers
[Learning Goal : Using Structures]
Define a struct with following members to store a rational number of the form p/q where q is
not equal to 0, q is always positive and p and q have no common factors.
int numer;// numerator
int denom;// denominator
Write a program to take two rational numbers given by the user and print their sum and
product. You will need to write separate functions for the sum and product and use a GCD
function to make sure that the numerator and denominator do not have any common factors.

*/

#include<stdio.h>
#include<stdlib.h>

typedef struct
{
	int numer;// numerator
    int denom;// denominator
	
}rational;

rational sumR(rational,rational);
rational prodR(rational,rational);
int gcd1(int,int);


int main()

{
	int p=0,q=0;
	rational r1,r2,sum,prod;
	
	
	printf("Enter Value for Numer 1 >> ");
	scanf("%d",&p);
	printf("Enter Value for Denom 1 >> ");
	scanf("%d",&q);
	
	if(q>0)
    {
	   r1.numer=p;
	   r1.denom=q;
	}
	else
	 printf("Invalid rational Number\n");
	
	printf("Enter Value for Numer 2 >> ");
	scanf("%d",&p);
	printf("Enter Value for Denom 2 >> ");
	scanf("%d",&q);
	
	if(q>0)
    {
	   r2.numer=p;
	   r2.denom=q;
	}
	else
	 printf("Invalid rational Number\n");
	 	
	printf("The first rational number is %d/%d\n",r1.numer,r1.denom);
	printf("The second rational number is %d/%d\n",r2.numer,r2.denom);
	
	prod=prodR(r1,r2);
	printf("The product is %d/%d\n",prod.numer,prod.denom);
	
	sum=sumR(r1,r2);
	printf("The sum is %d/%d\n",sum.numer,sum.denom);
	
	



    system("PAUSE");
    return 0;
}

rational prodR(rational p1,rational p2)
{
	rational prod;
	int gcd=1;
	prod.numer=p1.numer*p2.numer;
	prod.denom=p1.denom*p2.denom;
	
	gcd=gcd1(prod.numer,prod.denom);
	
	prod.numer=prod.numer/gcd;
	prod.denom=prod.denom/gcd;
	return prod;
	
}

rational sumR(rational p1,rational p2)
{
	rational sum;
	int gcd=1;
	sum.numer=p1.numer*p2.denom + p2.numer*p1.denom;	
	sum.denom= p1.denom*p2.denom;
	
	gcd=gcd1(sum.numer,sum.denom);
	
	sum.numer=sum.numer/gcd;
	sum.denom=sum.denom/gcd;
	return sum;
}

gcd1(int m , int n)
{
	int bigNum=0,smallNum=0,temp=0,gcd=0;
	if(n==0 || m==0)
        {
        printf("\nERROR: One of the values equals 0.\n");
        system("PAUSE");
        exit(0);
        }
        
    if(n>=m)
	{
	  bigNum=n;
	  smallNum=m;
	 } 
	else
	{
	  bigNum=m;
	  smallNum=n;	
	}
	while(smallNum!=0)
	{
		temp=bigNum%smallNum;
		bigNum=smallNum;
		smallNum=temp;
		
	}
    gcd=bigNum;
	
	return gcd;
}

