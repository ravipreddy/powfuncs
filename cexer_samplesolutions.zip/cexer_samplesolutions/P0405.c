/*
P0405 : LABS.C � Absolute value computation
[Learning Goal : Using labs function]
Write a program to read a long integer and print its absolute value using labs function.
*/
#include<stdio.h>
#include<stdlib.h>
#include<math.h>

int main()

{
    
	long int myNum=0,absValue=0;
    printf("Enter the integer value >> ");
    scanf("%ld",&myNum);

    absValue=labs(myNum);
    printf("Absolute Value of %ld is  %ld\n",myNum,absValue);


  system("PAUSE");
  return 0;
}

