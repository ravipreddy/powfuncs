/*
P0407 : ABS.C � Absolute value computation
[Learning Goal : Using abs function]
Write a program to read an integer and print its absolute value using abs function.
*/
#include<stdio.h>
#include<stdlib.h>
#include<math.h>

int main()

{
	long int myNum=0;
	long int absValue=0;
    printf("Enter the integer value >> ");
    scanf("%ld",&myNum);

    absValue=abs(myNum);
    printf("Absolute Value of %ld is  %ld\n",myNum,absValue);


  system("PAUSE");
  return 0;
}

