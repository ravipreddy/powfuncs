/*
P0308 : PERIM.C � Perimeter of a Triangle
[Learning Goal : arithmetic, io]
Given three decimal values entered by the user representing the lengths of the three sides of
triangle, compute and display the perimeter of the triangle.

*/

#include<stdio.h>
#include<stdlib.h>


int main()

{

  float len1=0.0,len2=0.0,len3=0.0, perimeter=0.0;
  
  
  printf("Enter  value for len1 >>");
  scanf("%f",&len1);
  printf("You have entered : %g\n",len1);
  
  printf("Enter  value for len2 >>");
  scanf("%f",&len2);
  printf("You have entered : %g\n",len2);
  
  printf("Enter  value for len3 >>");
  scanf("%f",&len3);
  printf("You have entered : %g\n",len3);
  
  
  
 

  perimeter=len1+len2+len3;
  printf("The perimeter of Triangle is %g\n",perimeter);
  
   
  
  
     
  system("PAUSE");
  return 0;
}

