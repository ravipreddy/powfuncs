/*
P0612 : GOODNUMS.C � Interesting Numbers
[Learning Goal : Simple looping]
Write a program that examines all the numbers from 1 to 999, displaying all those for which
the sum of cubes of the digits equals the number itself.
For example, given the number 563, 53 + 63 + 33 = 125 + 216 +27 =368, which is not equal
to 563.
On the other hand, given 371, 33 + 73 + 13 = 27 + 343 + 1 = 371.
*/

#include<stdio.h>
#include<stdlib.h>
#include<math.h>

int main()

{
    int myNum=1,i=0,sumNum=0,temp=0;
    int d1=0, d2=0, d3=0;

    for(i=1;i<=999;i++)
    {
    	d1=myNum/100;
    	d3=myNum%10;
    	temp=myNum/10;
    	d2=temp%10;

    	sumNum=d1*d1*d1 + d2*d2*d2 + d3*d3*d3;

    	if(sumNum==myNum)
    	  printf("%3d \n",myNum);

		sumNum=0;
		temp=0;
		myNum++;

	}

    system("PAUSE");
    return 0;
}

