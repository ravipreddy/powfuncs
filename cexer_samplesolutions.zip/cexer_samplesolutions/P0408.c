/*
P0408 : FLOORCEIL.C � Computing floor and ceiling functions
[Learning Goal : Using floor and ceil function]
Write a program to read a decimal value and print its floor value and ceiling value using the
floor and ceil functions. Try positive and negative decimal values as inputs. Try whole
numbers also as inputs.
*/
#include<stdio.h>
#include<stdlib.h>
#include<math.h>

int main()

{

  double myNum=0.0;
  int valFloor=0,valCeil=0;

  printf("Enter the decimal value >> ");
  scanf("%lf", &myNum);
  
  valFloor=floor(myNum);
  valCeil=ceil(myNum);
  
  printf("Floor Value of  %g is %d\n",myNum,valFloor);
  
  printf("Ceiling Value of  %g is %d\n",myNum,valCeil);
  
  

  system("PAUSE");
  return 0;
}

