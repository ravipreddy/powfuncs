/*
P0319 : CHANGE.C � Change Conversion
[Learning Goal : arithmetic, modulus operator, integer truncation]
Given a dollar amount, convert it into the appropriate change using least number of coins.
The change will be given in quarters (=25 cents each), dimes (=10 cents each), nickels (=5
cents each) or pennies (=1 cent each).
SAMPLE SESSION #01
Enter amount in dollars: 12.43
12 dollars, 1 quarter, 1 dime, 1 nickel, 3 pennies
*/

#include<stdio.h>
#include<stdlib.h>

int main()

{

  int dime=0,quarter=0,nickel=0,penny=0,intDol=0,temp=0;
  double dollar=0.0,fracDol=0.0;
  
  
  
  printf("Enter  the amount in Dollar  >>");
  scanf("%lf",&dollar);
  printf("You have entered : %2f\n",dollar);
  
  fracDol=(dollar-(int)dollar);
    
  
  intDol=(fracDol*100) + .5;
   
  quarter=intDol/25;
  temp=intDol%25;
  
  dime=temp/10;
  temp=temp%10;
  
     
  nickel=temp/5;
  penny=temp%5;
   
  printf("\nYou have %d dollar, %d quarter, %d dime, %d nickel, %d penny\n",  (int)dollar,quarter,dime,nickel,penny);    
  system("PAUSE");
  return 0;
}

