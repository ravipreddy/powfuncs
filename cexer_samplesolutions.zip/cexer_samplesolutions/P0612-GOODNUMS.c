/*
P0612 : GOODNUMS.C � Interesting Numbers
[Learning Goal : Simple looping]
Write a program that examines all the numbers from 1 to 999, displaying all those for which
the sum of cubes of the digits equals the number itself.
For example, given the number 563, 53 + 63 + 33 = 125 + 216 +27 =368, which is not equal
to 563.
On the other hand, given 371, 33 + 73 + 13 = 27 + 343 + 1 = 371.
*/

#include<stdio.h>
#include<stdlib.h>
#include<math.h>

int main()

{
    int myNum=1,i=0,sumNum=0,temp=0,temp1=0;

    for(i=0;i<=999;i++)
    {
    	temp1=myNum;
		while(temp1!=0)
		{
		  temp=temp1%10;
		  sumNum=sumNum+ temp*temp*temp;
		  temp1=temp1/10;
		}

    	if(sumNum==myNum)
    	  printf("%3d\n",myNum);

		sumNum=0;
		temp=0;
		myNum++;

	}

    system("PAUSE");
    return 0;
}

