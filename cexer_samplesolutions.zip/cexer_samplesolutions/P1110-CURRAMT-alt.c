/*
P1110 : CURRAMT.C � Currency to Words
[Learning Goal : Working with Strings]
Write a program which takes in a decimal number indicating a currency amount and prints it
out in words as required in financial documents.

*/

#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#include <string.h>

char myTeens[20][20]={"Zero","One","Two","Three","Four","Five","Six","Seven","Eight",
                "Nine","Ten","Eleven","Twelve","Thirteen","Fourteen","Fifteen","Sixteen",
                "Seventeen", "Eighteen","Nineteen"};
char myTens[10][20]={"","Ten","Twenty","Thirty","Forty","Fifty","Sixty",
                "Seventy","Eighty","Ninety"};


void inWords2Dig(int num, char * str)
{
    char tmp[100]="";
    int xtens,xunits;
    if(num<=19)
    {
        strcpy(str,myTeens[num]);
    }
    else
    {
        xunits = num%10;
        xtens  = num/10;
        strcat(tmp,myTens[xtens]);
        strcat(tmp," ");
        strcat(tmp,myTeens[xunits]);
        strcpy(str,tmp);
    }
    return;

}


int main()
{
 double myNum=0.0;
 unsigned long rPart=0,pPart=0,rupees;
 int lakhs,thousands,hundreds,last2;
 char strLakhs[100],strThousands[100],strHundreds[100],strLast2[100],strPaise[100];
 char amount[200];


	printf("Enter a decimal value of Currency >> ");
	scanf("%lf",&myNum);

	printf("Amount Entered >> %0.2lf\n",myNum);

	rPart=(int)(myNum);
	rupees = rPart;

	pPart=100*(myNum-rPart)+0.5;
	printf("Rs %d Paise %d\n",rPart,pPart);

 if(rPart >= 9999999)
 	{
 		printf("please enter a number between 0 and 10000000\n\n");
 		system("Pause");
		exit(0);
 	}

    last2 = rPart % 100;
    rPart /= 100;
    hundreds = rPart %10;
    rPart /= 10;
    thousands = rPart %100;
    rPart /= 100;
    lakhs = rPart;
    printf("%lu lakhs %lu thousands %lu hundreds %lu last 2\n\n",
        lakhs, thousands, hundreds, last2);

    inWords2Dig(lakhs,strLakhs);
    inWords2Dig(thousands,strThousands);
    inWords2Dig(hundreds,strHundreds);
    inWords2Dig(last2,strLast2);
    inWords2Dig(pPart,strPaise);
    printf(" [%s]  lakhs\n",strLakhs);
    printf(" [%s]  thousands\n",strThousands);
    printf(" [%s]  hundreds\n",strHundreds);
    printf(" [%s]  last2\n",strLast2);
    printf(" [%s]  paise\n",strPaise);

    strcpy(amount,"Rupees ");
    if(lakhs!=0)
        {
            strcat(amount,strLakhs);
            strcat(amount," Lakh ");
        }
    if(thousands!=0)
    {
        strcat(amount,strThousands);
        strcat(amount," Thousand ");
    }
    if(hundreds!=0)
    {
        strcat(amount,strHundreds);
        strcat(amount," Hundred ");
    }
    if(last2!=0)
    {
        strcat(amount,strLast2);
        strcat(amount," ");
    }
    if(rupees==0)
    {
        strcat(amount,"Zero ");
    }

    if(pPart!=0)
    {
        strcat(amount,"and Paise ");
        strcat(amount,strPaise);
        strcat(amount," ");
    }
    strcat(amount,"only");

    puts(amount);

return 0;
}
