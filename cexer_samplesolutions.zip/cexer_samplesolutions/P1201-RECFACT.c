/*
P1201 : RECFACT.C � Recursive Factorial Computation
[Learning Goal : Writing Recursive Functions]
Write a program which contains a recursive function rec_fact with following prototype.
long int rec_fact(long int n);
Use it to compute the factorial of a positive integer given by the user.
The function is based onthe following definition:
 n! = 1 if n equals 0
= n ? (n-1)!, otherwise.

*/

#include<stdio.h>
#include<stdlib.h>

long int rec_fact(long int n);

int main()

{
	long int myNum=0L;
    printf("Enter the Number : ");
    scanf("%ld",&myNum);

    printf("Factorial of %ld is %ld\n", myNum, rec_fact(myNum));



    system("PAUSE");
    return 0;
}

long int rec_fact(long int n)
    {
        if(n <= 1)
            return 1;

        return n * rec_fact(n - 1);
    }


