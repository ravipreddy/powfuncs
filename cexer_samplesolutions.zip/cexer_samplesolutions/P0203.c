#include<stdio.h>
#include<stdlib.h>

int main()

{

  char myChar;
  printf(" Please Enter a Character >> ");
  scanf("%c",&myChar);
  printf("ASCII value of Character [%c] is [%d]\n",myChar,myChar);
  
  
  system("PAUSE");
  return 0;
}

