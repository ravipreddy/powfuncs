/*
P0624 : DIV13.C � Sum of Harmonic Series
[Learning Goal : Simple looping]
Write a program the sum of harmonic series to n terms where n is input by the user.
Sn = 1/1+1/2+1/3+��+1/n
*/

#include<stdio.h>
#include<stdlib.h>

int main()

{
	int myNum=0,i=1;
	double sum=0.0;
	
	printf("Enter an integer value >> ");
    scanf("%d",&myNum);
    
    while(i<=myNum)
    {
    	sum=sum+(1.0/i);
    	i++;
	}
	
	printf("Sum of harmonic series from 1 to %d is %g\n",myNum,sum);


    system("PAUSE");
    return 0;
}

