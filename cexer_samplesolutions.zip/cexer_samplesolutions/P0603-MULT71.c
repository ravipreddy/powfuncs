/*
P0603 : MULT71.C � Multiples of 7
[Learning Goal : Simple looping]
Write a program to print the first 20 positive multiples of 7.
*/

#include<stdio.h>
#include<stdlib.h>

int main()

{
    int myNum=0,i=0;

    for(i=1;i<=20;i++)
    {
		myNum=7*i;
		printf("7 * %d = %d \n",i,myNum);

    }

    system("PAUSE");
    return 0;
}

