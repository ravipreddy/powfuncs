#include<stdio.h>
#include<stdlib.h>

int main()

{

  printf("This\rWorld\ris\rmine\n");
  printf("Hello\rWonderful\rWorld\n");

  system("PAUSE");
  return 0;
}



