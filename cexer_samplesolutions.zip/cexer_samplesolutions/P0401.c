//P0401 : SQROOT.C � Square Root of a Decimal Number
//[Learning Goal : using sqrt function]
/*Write a program which will take a positive decimal value as input and print its square root as
the output.*/

#include<stdio.h>
#include<stdlib.h>
#include<math.h>

int main()

{
    double myNum=0.0;
	double sqrtValue=0.0;

    printf("Enter an integer value >> ");
    scanf("%lf", &myNum);
    sqrtValue=sqrt(myNum); //sqrtValue=pow(num,0.5);
    printf("Square root value of %g is : %g\n", myNum,sqrtValue);


  system("PAUSE");
  return 0;
}

