/*
P0317 : INCHES.C � Length Conversion
[Learning Goal : arithmetic, modulus operator, integer truncation]
Given the length of a field in inches (whole number of inches), print it in terms of yards, feet
and inches.
[NOTE: 12 inches = 1 foot and 3 feet =1 yard]
SAMPLE SESSION #01
Enter length in inches : 139
139 inches equals 3 yards, 2 feet and 7 inches
SAMPLE SESSION #02
Enter length in inches : 786
786 inches equals 21 yards, 2 feet and 6 inches
*/

#include<stdio.h>
#include<stdlib.h>

int main()

{

  int len=0,feet=0 , yard=0,inch=0;
  
  
  
  printf("Enter  the length of Feild  >>");
  scanf("%d",&len);
  printf("You have entered : %d\n",len);
  
  
  
  feet=len/12;
  yard=feet/3;
  feet=feet%3;
  inch=len%12;
  
  
  
  printf("The %d length is %d yard and %d feet and %d inch\n",len,yard,feet,inch);
  
      
  system("PAUSE");
  return 0;
}

