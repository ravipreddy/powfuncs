/*
P0628 : DIV13.C � Checking for divisibility by 3
[Learning Goal : Using integer values of char]
A positive integer is divisible by 3 if the sum of its digits is 3, 6 or 9. Write a program using
this rule to check whether a given integer is divisible by 3 or not. DO not use the division or
modulo operator.
*/

#include<stdio.h>
#include<stdlib.h>

int main()

{
	int myNum=0,sumDigit=0,tempNum=0,myNum1=0;
	
	printf("Enter the positive number >> ");
    scanf("%d",&myNum);
    myNum1=myNum;
    
    while(myNum!=0)
    {
      tempNum=myNum%10;
      sumDigit=sumDigit+tempNum;
      myNum=myNum/10;
	  	
	}
	
	//printf("The sum of the digit of %d is %d\n",myNum1,sumDigit);
	
	if(sumDigit==3 || sumDigit==6 || sumDigit==9)
	 printf("The number %d is divisible by 3\n",myNum1);
	else
	 printf("The number %d is NOT divisible by 3\n",myNum1);

    system("PAUSE");
    return 0;
}

