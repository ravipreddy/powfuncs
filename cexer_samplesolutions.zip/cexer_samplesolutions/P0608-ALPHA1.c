/*
P0608 : ALPHA1.C � Uppercase Alphabet
[Learning Goal : Simple looping, using char as loop index]
Write a program to print the upper-case alphabet from A to Z.
*/

#include<stdio.h>
#include<stdlib.h>

int main()

{
    char myChar=NULL;
    
    for(myChar='A';myChar<='Z';myChar++)
       printf("%c  ",myChar);

    system("PAUSE");
    return 0;
}

