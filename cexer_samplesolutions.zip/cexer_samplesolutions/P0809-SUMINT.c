/*
P0809 : SUMINT.C � Sum of Integers
[Learning Goal : Sequential Fie IO]
Write a program to find the sum of all integers in a given file.
*/

#include<stdio.h>
#include<stdlib.h>

int main()

{
	FILE *fptr;
	int sum=0,myNum=0;
    char fileName[100], myChar1[100];

    printf("Enter the filename (input.txt) to open >> ");
    scanf("%s", fileName);
    

    fptr = fopen(fileName, "r");
    
    if (fptr == NULL)
    {
        printf("Cannot open file \n");
        exit(0);
    }
    
       
    while(!feof(fptr))
        {
        fscanf(fptr,"%d",&myNum);        
        sum=sum+myNum;
        }
        
    printf("Sum of the interger in file input.txt is %d \n",sum);
    
    fclose(fptr);
    
    system("PAUSE");
    return 0;
}

