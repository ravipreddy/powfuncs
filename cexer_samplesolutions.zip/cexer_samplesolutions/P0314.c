/*
P0314 : RECIP2.C � Integer Reciprocal Computation
[Learning Goal : arithmetic, io, integer division]
Given an integer value, print its reciprocal value. For a number p, the reciprocal is defined as
the value 1/p. [This can be tricky because 1/4 results in 0 and not 0.25 according to definition
of division operator for integers]

*/

#include<stdio.h>
#include<stdlib.h>

int main()

{

  int val=0;
  double reci=0.0;
  
  
  printf("Enter  integer value  >>");
  scanf("%d",&val);
  printf("You have entered : %d\n",val);
  
  reci=(double)1/val;
  //type casting integer value to double
  // You can also do 1.0/val
  
  printf("The reciprocal of %d is %lg\n",val,reci);
  
      
  system("PAUSE");
  return 0;
}

