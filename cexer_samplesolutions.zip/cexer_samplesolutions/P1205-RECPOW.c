/*
P1205 : RECPOW.C � Recursive Power Function
[Learning Goal : Writing Recursive Functions]
The following is a recursive method for calculating ipow(x,n) = xn for positive integral values
of n.
ipow(x,n) = ipow(x,n/2) * ipow(x,n/2) if x is even
= ipow(x,n/2) * ipow(x,n/2) * x if x is odd
= 1 if x equals 0
Implement this recursive function and test it for some values of x.
double rec_pow(double x, int n);
*/

#include<stdio.h>
#include<stdlib.h>

double  rec_pow(long int  x, long int n);

int main()

{
	long int pow=0;
	long int num=0;

    printf("Enter positive integers : ");
    scanf("%ld", &num);
    printf("Enter the Power : ");
    scanf("%ld", &pow);

    printf("Value = %lg \n", rec_pow(num,pow));



    system("PAUSE");
    return 0;
}

double  rec_pow(long int x, long int n)
{
    if(n==0)
        return 1;

    else if(n%2==0)
        return rec_pow(x,n/2)*rec_pow(x,n/2);

    else
       return rec_pow(x,n/2)*rec_pow(x,n/2)*x;
}



