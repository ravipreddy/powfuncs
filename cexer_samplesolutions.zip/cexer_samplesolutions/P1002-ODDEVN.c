/*
P1002 : ODDEVN.C � Sum of Odd and Even Values
[Learning Goal : Using One Dimensional Arrays]
Write a program to read a set of positive integer values from a text file and store them in an
integer array. The program then computes the sum of the odd integers and the even integers
and displays these sums.
SAMPLE SESSION #01---------------
Name of data file >> vals.txt
113 values read from file
Sum of odd integers = 2345
Sum of even integers = 4568
*/

#include<stdio.h>
#include<stdlib.h>

int main()

{
    FILE *fptr;
    char fileName[100] ;
    int i=0,count=0,myNum[100],sumOdd=0,sumEven=0;


    printf("Enter the file(vals.txt) to be opened >>");
    gets(fileName);


    fptr=fopen(fileName,"r");

    while(!feof(fptr))
        {
        fscanf(fptr,"%d",&myNum[i]);
        count++;
        i++;
        }

    printf("The total values are %d\n",count);

    for(i=0;i<count;i++)
    {
    	if(myNum[i]%2==0)
            sumEven=sumEven+myNum[i];
        else
            sumOdd=sumOdd+myNum[i];
	}

	printf("The sum of Odd Integer is %d\n",sumOdd);
	printf("The sum of Even Integer is %d\n",sumEven);

    system("PAUSE");
    return 0;
}

