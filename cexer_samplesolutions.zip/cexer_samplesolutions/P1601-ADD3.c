/*
P1601 : ADD3.C � Add 3 integers
[Learning Goal : Using Command Line Arguments]
Write a program to take 3 integer values as arguments and print their sum and product. It
must show an error if fewer than 3 arguments are given.
c:\ add3 3 4 5
Sum = 12
Product = 60

*/

#include<stdio.h>
#include<stdlib.h>

int main( int argc, char * argv[])

{
	int i=0, sum = 0,product=1;
	
	if (argc != 4)  
	{
      printf("You have forgot to type all numbers.");
      exit(1);
    }
    
    for (i = 1; i < argc; i++)
    {
       sum = sum + atoi(argv[i]);
       product=product*atoi(argv[i]);
    }
      
    printf("Sum of number is : %d\n",sum);
    printf("Product of number is : %d\n", product);

    system("PAUSE");
    return 0;
}

