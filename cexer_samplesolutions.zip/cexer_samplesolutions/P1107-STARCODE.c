/*
P1107 : STARCODE.C � Star Code
[Learning Goal : Working with Strings]
Write a program which takes in a line of text entered by the user. All text is converted to
lowercase and then each word is replaced by 3 characters � the first letter followed by a star
'*" and then the last letter of the word.
*/

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int main()

{
	char myChar[100],copyText[100],lastChar;
	int i=0,j=0;
	
	printf("Enter a line of text >> ");
	gets(myChar);
	
	for(i=0; myChar[i]!='\0';i++)
	{
		
		copyText[j]=tolower(myChar[i]);
		j++;
		copyText[j]='*';
		j++;
		
		
		     while(myChar[i]!= ' ')
		      {
			   i++;
			   
			   if(myChar[i]!=' ')
			     copyText[j]=tolower(myChar[i]);
			   
			   else
			     {
			     	j++;
			     	copyText[j]=' ';
				 }	
			   
			   //printf(" %d %d %c %c ",i,j,myChar[i],copyText[j]);
			   
			   if(myChar[i]=='\0')
			    {
			    	copyText[j]=tolower(myChar[--i]);
					break;
			    	//system("PAUSE");
		        }
			}
	    
		j++;
		//printf("\n");
		
		copyText[j]=tolower(myChar[i]);	  	  
		 //printf(" 2 %d %c ",i,copyText[j]);  
          
        		  	
		
	}
	copyText[j]='\0';
   
   printf("Final The Modified String is [%s] \n",copyText);


    system("PAUSE");
    return 0;
}

