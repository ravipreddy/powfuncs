/*
P0807 : WCOUNT.C � Display File Contents
[Learning Goal : Sequential Fie IO]
Write a program which will display the number of words in a text file.
*/

#include<stdio.h>
#include<stdlib.h>
#include<ctype.h>

int main()

{
	FILE *fptr,*cptr,*fptr1;
	int count=0,sCount=0;
	
    char fileName[100], fileCopy[100], myChar,myChar1;

    printf("Enter the filename (remo.txt) to open >> ");
    scanf("%s", fileName);
    

    fptr = fopen(fileName, "r");
    fptr1=fopen(fileName, "r");
    
    if (fptr == NULL)
    {
        printf("Cannot open file \n");
        exit(0);
    }

    myChar1=fgetc(fptr1);
    while((myChar=fgetc(fptr))!= EOF)
	{
        myChar1=fgetc(fptr1);
        
        
		if(isgraph(myChar) && !isgraph(myChar1) )
		{
		  //printf("[%c] [%c]\n",myChar,myChar1); 
		  sCount++;
		  
		  
	    }

		
		
		 
    } 
    
    printf("Total word in file %s is %d \n",fileName,sCount);

    fclose(fptr);
    printf("\n");



    system("PAUSE");
    return 0;
}

