/*
P0909 : HERON.C � Heron's Formula
[Learning Goal : Writing User Defined Functions]
The area of any triangle can be calculated by Heron's formula, which defines the semiperimeter, s, as half of the sum of the sides of the triangle, The area of the triangle then is
given by the formula
area = (s*(s-a)*(s-b)*(s-c))^1/2
where a, b, and c are the sides of the triangle and s is the semi-perimeter defined as
s = (a+b+c)/2
Write a function which, when passed the sides of a triangle, returns the area using Heron's
formula. The function should first make sure the triangle is valid; if it is not, the function can
return zero or a negative value as an error indicator.
double area_heron(double a, double b, double c);

*/

#include<stdio.h>
#include<stdlib.h>
#include<math.h>
double area_heron(double a, double b, double c);

int main()

{
	double a=0.0,b=0.0,c=0.0;

	printf("Enter the Value a >> ");
	scanf("%lg",&a);

	printf("Enter the Value b >> ");
	scanf("%lg",&b);

	printf("Enter the Value c >> ");
	scanf("%lg",&c);

	printf("The area triangle for side %lg %lg %lg is %lg\n",a,b,c,area_heron(a,b,c));


    return 0;
}
double area_heron(double a, double b, double c)
{
	double area=0.0;
	double s=0.0;

	if(a+b<c || b+c<a || c+a<b)
	    return -1;
	else
        {
        s=(a+b+c)/2;
        area = sqrt(s*(s-a)*(s-b)*(s-c));
        return area;
        }


}
