/*
P1305 : CCOUNT.C � Character Count Function
[Learning Goal : Using Pointers]
Write a function that accepts a string and determines the number of times a given character
appears in it. For example, if the string is "Malayalam", and the character is 'a', your program
should print the value 4. Use a function with following prototype:
int my_strchr_count(char *s, char c);
*/

#include<stdio.h>
#include<stdlib.h>
int my_strchr_count(char *s, char c);

int main()

{
	char myChar[100],charS='\0';
	
	printf("Enter the String >> ");
	gets(myChar);
	
	printf("Enter the Character your want to count >> ");
	scanf("%c",&charS);
	
	printf("The count of [%c]in [%s] is %d\n",charS,myChar,my_strchr_count(myChar,charS));


    system("PAUSE");
    return 0;
}
int my_strchr_count(char *s, char c)
{
	int count=0,i=0;
	
	while(s[i]!='\0')
	{
	  if(s[i]==c)
	   count++;
	  i++; 	
	}
	return count;
}
