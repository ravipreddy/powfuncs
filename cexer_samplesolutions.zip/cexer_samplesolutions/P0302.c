/*
P0302 : ARITH1.C � Integer Arithmetic
[Learning Goal : integer arithmetic]
STYLE NOTE : It is an old and customary style to name integer variables starting with the
letters 'i' through 'n', i.e., name integer variables to start with the letters i, j, k, l, m, or n.
Read in two integer values j and k entered by the user and print out the values of the
following expressions
j+k j-k j*k j/k j%k
Run your program for the following cases:
(a) Both inputs are positive integers
(b) Both inputs are negative integers
(c) One is positive and the other is negative.
*/

#include<stdio.h>
#include<stdlib.h>


int main()

{

  int j=0,k=0;
  
  
  printf("Enter value for j >>");
  scanf("%d",&j);
  printf("You have entered : %d\n",j);
  
  printf("Enter value for k >>");
  scanf("%d",&k);
  printf("You have entered :%d\n",k);
  
  
  
  printf("Result of j+k is %d\n",j+k);
  printf("Result of j-k is %d\n",j-k);
  printf("Result of j*k is %d\n",j*k);
  printf("Result of j+k is %d\n",j-k);
  printf("Result of j/k is %d\n",j/k);
  printf("Result of j%%k is %d\n",j%k);
  
  system("PAUSE");
  return 0;
}

