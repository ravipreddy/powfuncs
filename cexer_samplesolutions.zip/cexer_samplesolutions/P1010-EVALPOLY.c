/*
P1010 : EVALPOLY.C � Polynomial Evaluation
[Learning Goal : Using One Dimensional Arrays]
A real polynomial P(x) of degree n or less is given by
P(x)=a0+a1x+a2x2+����+anxn
The coefficients of the polynomial can be stored as an array. Write a function for evaluating
the polynomial for a given value of x.
double evalpoly(double p[ ],double x, int n);
The function should evaluate the polynomial by using the efficient Horner�s Rule (using nested
multiplication to reduce the total number of multiplications). For fifth-degree polynomials,
Horner�s Rule is expressed by writing
P(x)=a0+x(a1+(a2+(a3+x(a4+x(a5)))))
*/

#include<stdio.h>
#include<stdlib.h>

double horner(double poly[], int n, double x) ;

int main()

{
	double array[]={2.2,3.3,-4,-1},result=0.0,x=0.0;
	int size=0,i=0;
	
	size=sizeof(array)/sizeof(double);
	
	printf("The coeff of poly are\n");
	
	for(i=0;i<size;i++)
	  printf("%lg\t",array[i]);
	
	printf("\nEnter Value for x>> ");
	scanf("%lg",&x);
	
	result=horner(array,size,x) ;
	
	printf("The value for x = %lg is : %lg",x,result);


    printf("\n");
	system("PAUSE");
    return 0;
}

double horner(double poly[], int n, double x) 
{ 
    int i=0;
	double result1 = poly[0],result=0;
  
    // Evaluate value of polynomial using Horner's method 
    for ( i=n-1; i>0; i--) 
        {
        	result = (result + poly[i])*x; 
        	        	
		}
    result=result1+result;
    return result; 
} 

