/*
P0709 : PRFACT.C � Prime Factors
[Learning Goal : Nested Looping]
Write a C program that will accept input of a positive integer value and output the prime
factorization of the input value.
(Hint: The outer loop goes through the factors. The inner loop checks out how many times a
factor is repeated)
Input an integer >> 1050
The prime factorization of 1050 is
2 * 3 * 5 * 5 * 7
*/

#include<stdio.h>
#include<stdlib.h>

int main()

{
	int myNum=0,r,c,i;
        printf("Enter the number >> ");
        scanf("%d",&myNum);
        
         while (myNum%2 == 0)
        {
            printf(" %d *", 2);
            myNum = myNum/2;
        }


    for (i=3;i<=sqrt(myNum);i=i+2)
    {
        while (myNum%i == 0)
        {
            printf("%d *", i);
            myNum = myNum/i;
        }
    }

    if (myNum>2)
        printf ("%d *", myNum);

    printf("\b ");



    system("PAUSE");
    return 0;
}

