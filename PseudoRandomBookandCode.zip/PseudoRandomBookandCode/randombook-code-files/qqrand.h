#ifndef ___qq_rand_library___
#define ___qq_rand_library___
unsigned int qq_rand_raw();
unsigned int qq_rand_max();
void qq_rand_seed(unsigned int newseed);
double qq_rand_dbl();
int qq_rand_interval(int min, int max);
int qq_rand_roulette(int nvals, double * odds);
unsigned int qq_rand_timeseed();
void qq_rand_perm1(int n, int * perm);
void qq_rand_perm2(int n, int * perm);
double qq_rand_gauss();

typedef struct
	{
	int index;
	unsigned int randint;} 
RVALPAIR;

#define QQ_RANDMAX (UINT_MAX -1)
#define QQ_RANDMAXPLUSONE UINT_MAX
#define QQ_DEFAULTSEED  (789)
#define QQ_DELTA 1.E-8

#endif