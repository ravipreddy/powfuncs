#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "qqrand.h"


int main(int argc, char **argv)
{
	unsigned int seed=88;
	int i,np=20;
	FILE * outfile;
	double x,y;
	
    if(argc<3)
		{
			printf("Usage: ngauss N seed\n");
			printf("  where N is number of points to be generated\n");
			printf("  and seed is the seed value for the PRNG.\n");
			exit(0);
		}
	outfile = fopen("gauss.txt","w");
	if(outfile==NULL)
		{
			printf("\nError: Unable to open gauss.txt\a\a\n");
			exit(0);
		}	
	np = atoi(argv[1]);
	seed = atoi(argv[2]);
	qq_rand_seed(seed);
	
	for(i=0;i<np;i++)
		{
			x = qq_rand_gauss();
			printf("%d %14.8lf\n",i,x);
			fprintf(outfile,"%d\t%14.8lf\n",i,x);
		}
	fclose(outfile);
	
	return 0;
}

