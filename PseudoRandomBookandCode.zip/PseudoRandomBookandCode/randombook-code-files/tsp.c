#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "qqrand.h"
#define MAXCITY 100
double travel_distance(int ncity, int *perm, double *xc, double *yc);
double distance(double x1, double y1, double x2, double y2);

int main()
{
	int i,j;
	double d1,dmin,d2;
	double xc[10]={10,20,30,60,70,80,35,75,85,25};
	double yc[10]={10,90,60,10,80,30,75,95,25,50};
	int perm[9] ={0,1,2,3,4,5,6,7,8};
	int bestperm[9];
	FILE *outfile;
	outfile = fopen ("tsp.txt","w");
	
	for(i=0;i<10;i++)
	{
		printf("x,y = %lf %lf\n",xc[i],yc[i]);
		fprintf(outfile,"x,y =\t%lf\t%lf\n",xc[i],yc[i]);
	}
	
	fprintf(outfile,"\n\n");
	
	fprintf(outfile,"%d\t%lf\t%lf\n",9,xc[9],yc[9]);
	for(i=0;i<9;i++)
	{
		printf("x,y = %lf %lf\n",xc[i],yc[i]);
		fprintf(outfile,"x,y\t%lf\t%lf\n",xc[i],yc[i]);
	}	
	fprintf(outfile,"%d\t%lf\t%lf\n",9,xc[9],yc[9]);
	
	d1 = travel_distance(10,perm,xc,yc);
	printf("dist = %lf\n",d1);
	fprintf(outfile,"dist =\t%lf\n\n\n",d1);
	dmin = d1;
	
	qq_rand_seed(0);
	
	for(j=0;j<100;j++)
		{
		qq_rand_perm1(9,perm);
		d2 = travel_distance(10,perm,xc,yc);
		printf("[%d] dist = %lf\n",j,d2);
		if(d2<dmin)
			{
				dmin = d2;
				for(i=0;i<9;i++)
					bestperm[i]=perm[i];				
			}
		}
	printf("Best path found, distance = %lf\n",dmin);
	printf("%d \n",9);
	for(i=0;i<9;i++)
		printf("%d ",bestperm[i]);
	printf("%d \n",9);
	
	fprintf(outfile,"%d\t%lf\t%lf\n",9,xc[9],yc[9]);
	for(i=0;i<9;i++)
	{
		printf("x,y = %lf %lf\n",xc[bestperm[i]],yc[bestperm[i]]);
		fprintf(outfile,"x,y\t%lf\t%lf\n",xc[bestperm[i]],yc[bestperm[i]]);
	}	
	fprintf(outfile,"%d\t%lf\t%lf\n",9,xc[9],yc[9]);
	fprintf(outfile,"Best path \t%lf\n",dmin);	
	fclose(outfile);
	return 0;
}

double travel_distance(int ncity, int *perm, double *xc, double *yc)
{
	double dist=.0;
	int j;
//	printf("%d %d\n",ncity-1,0);
//	printf("%d %d\n",ncity-1,perm[ncity-2]);
	dist  = distance(xc[ncity-1],yc[ncity-1],xc[perm[0]],yc[perm[0]]);
	dist += distance(xc[ncity-1],yc[ncity-1],xc[perm[ncity-2]],yc[perm[ncity-2]]);
	for(j=0;j<ncity-2;j++)
	{
//		printf("%d %d\n",perm[j],perm[j+1]);
		dist +=distance(xc[perm[j]],yc[perm[j]],xc[perm[j+1]],yc[perm[j+1]]);
	}
	return dist;
}

double distance(double x1, double y1, double x2, double y2)
{
	return sqrt((x1-x2)*(x1-x2)+(y1-y2)*(y1-y2));
}



