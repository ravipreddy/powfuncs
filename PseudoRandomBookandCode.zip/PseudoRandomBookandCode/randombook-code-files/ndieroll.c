//program: dieroll.c
#include <stdio.h>
#include <stdlib.h>
#include "qqrand.h"


int main(int argc, char ** argv)
{
    int i,j,nroll,ndice,val,* bins;
	int kmin,kmax;
	FILE * binfile;

    if(argc<3)
		{
			printf("Usage: dieroll N M\n");
			printf("  where N is number of times you want to roll the dice\n");
			printf("  and M is number of dice\n");
			exit(0);
		}
		
    nroll = atoi(argv[1]);
	ndice = atoi(argv[2]);
	qq_rand_seed(0);
	kmin = ndice;
	kmax = ndice*6;
	bins = (int *)calloc(kmax+1,sizeof(int));
	binfile = fopen("bindata.txt","w");
	if(binfile==NULL)
		{
			printf("\nError: Unable to open bindata.txt\a\a\n");
			exit(0);
		}
    printf("\n%d rolls of a %d 6 sided dice.\n",nroll,ndice);
    for (i=0; i<nroll; i++) 
      {
		val=0;
		for(j=0;j<ndice;j++)
		val += qq_rand_interval(1,6);
		bins[val]++;
		printf("[%3d] ",val);
		if ((i+1)%10==0) printf("\n");
      }
	printf("\n");
    for(i=kmin;i<=kmax;i++)
	{
		printf(" bin [%d]=%d\n",i,bins[i]);
		fprintf(binfile,"%d\t%d\n",i,bins[i]);
	}
	fclose(binfile);
    return 0;
}
