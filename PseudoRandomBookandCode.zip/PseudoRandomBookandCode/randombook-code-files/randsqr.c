#include <stdio.h>
#include <stdlib.h>
#include "qqrand.h"


int main(int argc, char **argv)
{
	unsigned int seed=88;
	int i,np=20;
	FILE * outfile;
	double x,y;
	
    if(argc<3)
		{
			printf("Usage: randreal N seed\n");
			printf("  where N is number of points to be generated\n");
			printf("  and seed is the seed value for the PRNG.\n");
			exit(0);
		}
	outfile = fopen("square.txt","w");
	if(outfile==NULL)
		{
			printf("\nError: Unable to open square.txt\a\a\n");
			exit(0);
		}	
	np = atoi(argv[1]);
	seed = atoi(argv[2]);
	qq_rand_seed(seed);
	
	for(i=0;i<np;i++)
		{
			x = qq_rand_dbl();
			y = qq_rand_dbl();
			printf("%d %14.8lf %14.8lf\n",i,x,y);
			fprintf(outfile,"%d\t%14.8lf\t%14.8lf\n",i,x,y);
		}
	fclose(outfile);
	
	return 0;
}

