//program: dieroll.c
#include <stdio.h>
#include <stdlib.h>
#include "qqrand.h"
int qq_rand_roulette(int nvals, double * odds);

int main(int argc, char ** argv)
{
    int i,nroll,val,bins[7]={0};
	double odds[]={0.16,0.16,0.16,0.16,0.20,0.16};

    if(argc<2)
		{
			printf("Usage: dieroll N\n");
			printf("  where N is number of times you want to roll the dice\n");
			exit(0);
		}
		
    nroll = atoi(argv[1]);
	qq_rand_seed(0);

    printf("\n%d rolls of a 6 sided die.\n",nroll);
    for (i=0; i<nroll; i++) 
      {
      val = 1+qq_rand_roulette(6,odds);
      bins[val]++;
      putchar('0'+val);
      if ((i+1)%50==0) printf("\n");
      }
	printf("\n");
    for(i=1;i<=6;i++)printf("  [%1d] ",i);
	printf("\n");
	for(i=1;i<=6;i++)printf("%4d  ",bins[i]);
	printf("\n");
    return 0;
}
