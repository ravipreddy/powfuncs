//program: dieroll.c
#include <stdio.h>
#include <stdlib.h>
#include "qqrand.h"


int main(int argc, char ** argv)
{
    double x;
    int ntoss,j,heads=0,tails=0;
	
    if(argc<2)
		{
			printf("Usage: cointoss N\n");
			printf("  where N is number of times you want to toss the coin\n");
			exit(0);
		}
		
    ntoss = atoi(argv[1]);
	qq_rand_seed(0);

    for(j=0;j<ntoss;j++)
       {
       x=qq_rand_dbl();
       if(x<0.7)
         {
         putchar('H');
         heads++;
         }
       else
         {
         putchar('T');
         tails++;
         }
		if((j+1)%50==0)putchar('\n');
       } 
    printf("\nheads=%d\ttails=%d\n",heads,tails);
	return 0;
}
