#include <stdio.h>
#include <stdlib.h>
#include "qqrand.h"


int main(int argc, char **argv)
{
	unsigned int seed=88;
	int i,np=20;
	
    if(argc<3)
		{
			printf("Usage: nunif N seed\n");
			printf("  where N is number of points to be generated\n");
			printf("  and seed is the seed value for the PRNG.\n");
			exit(0);
		}
	
	np = atoi(argv[1]);
	seed = atoi(argv[2]);
	qq_rand_seed(seed);
	
	for(i=0;i<np;i++)
		printf("raw[%02d] = %14.8lf\n",i,qq_rand_dbl());
	
	return 0;
}

