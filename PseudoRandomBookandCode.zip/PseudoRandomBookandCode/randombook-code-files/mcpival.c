#include <stdio.h>
#include <stdlib.h>
#include "qqrand.h"


int main()
{
	unsigned int seed;
	int i,np=10000;
	FILE * outfile;
	double x,y,rsqr,pival;
	int inside=0,outside=0;

	qq_rand_seed(0);
	
	for(i=0;i<np;i++)
		{
			x = qq_rand_dbl();
			y = qq_rand_dbl();
			rsqr = x*x + y*y;
			if(rsqr > 1.0) outside++;
			else inside++;
		}
	printf(" inside points = %d\n",inside);
	printf("outside points = %d\n",outside);
	pival = 4.0*inside/(inside+outside);
	printf("Value of pi = %lf\n",pival);	
	return 0;
}

